"""oTree production: 3 catastrophe sessions + 4 real-effort sessions."""
from os import environ

# Independent sessions, each with its own standard /join/<code> link.
SESSION_CONFIGS = [
    # Catastrophe: 0, 2, or 4 of 4 members affected.
    dict(name='catastrophe_control_0', display_name='カタストロフ・被害なし',
         app_sequence=['cateffortinst4','cateffort4_2'], num_demo_participants=4,
         num_affected_players=0, real_world_currency_per_point=0.0),
    dict(name='catastrophe_loss_2', display_name='カタストロフ・2人被害',
         app_sequence=['cateffortinst4','cateffort4_2'], num_demo_participants=4,
         num_affected_players=2, real_world_currency_per_point=0.0),
    dict(name='catastrophe_all_4', display_name='カタストロフ・全員被害',
         app_sequence=['cateffortinst4','cateffort4_2'], num_demo_participants=4,
         num_affected_players=4, real_world_currency_per_point=0.0),
    # Real Effort: effort/no effort x variable/fixed endowment.
    dict(name='effort_variable', display_name='Real Effort・努力あり×変動あり',
         app_sequence=['pubeffort_inst','pubeffort'], num_demo_participants=4,
         condition='effort_variable', real_world_currency_per_point=1.0),
    dict(name='no_effort_variable', display_name='Real Effort・努力なし×変動あり',
         app_sequence=['pubeffort_inst','pubeffort'], num_demo_participants=4,
         condition='no_effort_variable', real_world_currency_per_point=1.0),
    dict(name='effort_fixed', display_name='Real Effort・努力あり×変動なし',
         app_sequence=['pubeffort_inst','pubeffort'], num_demo_participants=4,
         condition='effort_fixed', real_world_currency_per_point=1.0),
    dict(name='no_effort_fixed', display_name='Real Effort・努力なし×変動なし',
         app_sequence=['pubeffort_inst','pubeffort'], num_demo_participants=4,
         condition='no_effort_fixed', real_world_currency_per_point=1.0),
]

# if you set a property in SESSION_CONFIG_DEFAULTS, it will be inherited by all configs
# in SESSION_CONFIGS, except those that explicitly override it.
# the session config can be accessed from methods in your apps as self.session.config,
# e.g. self.session.config['participation_fee']

SESSION_CONFIG_DEFAULTS = dict(
    real_world_currency_per_point=1.00, participation_fee=0.00, doc=""
)

PARTICIPANT_FIELDS = ['is_admitted']
SESSION_FIELDS = []

# ISO-639 code
# for example: de, fr, ja, ko, zh-hans
LANGUAGE_CODE = 'ja'

# e.g. EUR, GBP, CNY, JPY
REAL_WORLD_CURRENCY_CODE = 'JPY'
USE_POINTS = True

ROOMS = [
    dict(
        name='econ101',
        display_name='Econ 101 class',
        participant_label_file='_rooms/econ101.txt',
    ),
    dict(name='live_demo', display_name='Room for live demo (no participant labels)'),
    dict(name='gmo', display_name='Room for gmo demo (no participant labels)'),
    dict(
        name='econ3000', 
        display_name='Room for n3000',
        participant_label_file='_rooms/3000.txt',
    ),
]

ADMIN_USERNAME = 'admin'
# for security, best to set admin password in an environment variable
ADMIN_PASSWORD = environ.get('OTREE_ADMIN_PASSWORD')

DEMO_PAGE_INTRO_HTML = """
Here are some oTree games.
"""
DEBUG = True

OTREE_AUTH_LEVEL = 'STUDY'
#environ['DATABASE_URL'] = 'postgres://postgres:localpgql@localhost/local_otree_pg'

environ['DATABASE_URL'] = 'postgresql://postgres:localpgql@localhost/local_otree_pg'

SECRET_KEY = '1719882799927'

INSTALLED_APPS = ['otree']

# adjustments for testing
# generating session configs for all varieties of features
import sys


if sys.argv[1] == 'test':
    MAX_ITERATIONS = 5
    FREEZE_TIME = 0.1
    TRIAL_PAUSE = 0.2
    TRIAL_TIMEOUT = 0.3

    SESSION_CONFIGS = [
        dict(
            name=f"testing_sliders",
            num_demo_participants=1,
            app_sequence=['sliders'],
            trial_delay=TRIAL_PAUSE,
            retry_delay=FREEZE_TIME,
            num_sliders=3,
            attempts_per_slider=3,
        ),
    ]
    for task in ['decoding', 'matrix', 'transcription']:
        SESSION_CONFIGS.extend(
            [
                dict(
                    name=f"testing_{task}_defaults",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                ),
                dict(
                    name=f"testing_{task}_retrying",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                    attempts_per_puzzle=5,
                ),
                dict(
                    name=f"testing_{task}_limited",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                    max_iterations=MAX_ITERATIONS,
                ),
            ]
        )

