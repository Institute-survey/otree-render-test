# oTree 本番用（7条件）

本パッケージは、**カタストロフ3条件**と**Real Effort 4条件**を同一oTreeサーバーで運用する完成版です。条件ごとに独立したセッションを作成し、oTree標準の `/join/ランダムコード` を使用します。テスト用セッション・短縮ルート・Botは含みません。

## フォルダ構成

- `cateffortinst4/`：カタストロフの教示・練習
- `cateffort4_2/`：カタストロフ本実験、事後質問票、デブリーフィング、パスワード
- `pubeffort_inst/`：Real Effortの教示・練習、条件別資源CSV
- `pubeffort/`：Real Effort本実験、事後質問票、パスワード
- `settings.py`：本番用7条件のセッション設定
- `requirements.txt`：oTree依存関係

## セッション設定（合計7）

| 実験 | oTree設定名 | 条件 |
| --- | --- | --- |
| カタストロフ | `catastrophe_control_0` | 被害0/4人（損失可能性は事前予告） |
| カタストロフ | `catastrophe_loss_2` | 被害2/4人 |
| カタストロフ | `catastrophe_all_4` | 被害4/4人 |
| Real Effort | `effort_variable` | 努力あり・変動あり |
| Real Effort | `no_effort_variable` | 努力なし・変動あり |
| Real Effort | `effort_fixed` | 努力あり・変動なし |
| Real Effort | `no_effort_fixed` | 努力なし・変動なし |

カタストロフの1/4人・3/4人被害は設定から削除済みです。被害者は最初の4人のグループ成立時にランダム抽選し、第5ラウンド終了後に被害対象者の累積ポイントを30%にします。被害なし条件でも損失可能性の予告は共通で、実際の損失は発生しません。

## 維持している実験仕様

- 4人グループを最初に形成し、10ラウンド固定。
- 全ラウンドで各参加者の拠出画面を開いた時刻から300秒以内に回答する必要があり、1人でも期限を超えると4人のグループ全体を中止します。結果待機画面の独立した600秒タイムアウトは廃止しました。スライダータスクは30秒です。
- 各ラウンドに獲得・割り当てられたポイントのみ拠出でき、累積ポイントは拠出不可。HTMLスライダーの上限は数値値を使用し、既定値100に戻る問題を修正済み。
- 両実験で最終質問票22項目をoTree内で1ページ表示。カテゴリタイトルは表示せず、回答ラベルを表示し、質問領域と項目順を参加者単位でランダム化。途中中止者には質問票を出さない。
- カタストロフ：最終質問票→デブリーフィング→パスワード入力→終了。Real Effort：最終質問票→パスワード入力→終了。
- フィードバック画面は時計を表示しないが、既存の自動遷移時間を維持。

## 実施方法

1. サーバー上で`python -m pip install -r requirements.txt`を実行する。
2. 本番用に`OTREE_ADMIN_PASSWORD`、`OTREE_SECRET_KEY`、`DATABASE_URL`等の環境変数を設定する。データベース設定は既存のサーバー環境に合わせる。
3. `otree prodserver 8000`で起動する。
4. 管理画面で各条件のセッションを作成し、生成された標準の「Session-wide link」を条件別に配布する。1セッションあたりの参加者枠は4人の倍数を基本とする。

**注意**：この`settings.py`は本番用7条件のみの独立プロジェクトを想定しています。既存サーバーの全アプリの設定を保持したい場合、`settings.py`は丸ごと上書きせず、必要な7条件を既存設定に統合してください。既存の参加データがあるサーバーで`otree resetdb`を実行しないでください。

ポイント円換算は前版から変更していません（カタストロフ：`real_world_currency_per_point=0.0`、Real Effort：`1.0`）。報酬換算については実施前に必ず確認してください。

## 離脱判定の詳細

- 各参加者が各ラウンドの拠出画面を初めて開いた時刻を`participant.vars`に記録します。画面の再読み込みでは起点をリセットしません。
- 拠出画面の期限は各参加者それぞれ300秒です。回答未提出の参加者の期限を超えたら、`decision_timeout`で所属グループを中止します。
- 結果待機は2秒ごとに回答状態を照会し、全員が提出済みなら次画面へ進みます。回答が揃わない場合は、未提出者の**拠出開始時刻に基づく期限**で中止します（追加の待機制限なし）。
- 未提出者が拠出画面に一度も到達していない場合、拠出タイマーはまだ開始されていません。通常のoTree本番サーバーでは先行画面のタイムアウトによる自動進行に依存します。この経路も本番前に確認してください。
- `round_wait_timeout`という中止理由は廃止し、拠出未提出による中止は`decision_timeout`に統一します。初回マッチングの300秒制限は別に維持します。
- 今回は既存のモデル項目を追加・削除せず、タイマー記録を`participant.vars`に保存することで、データベース構造の変更を避けています。

## 検証について

Python構文・7条件のみの登録・テスト専用機能の削除・ZIP整合性を静的確認しています。oTree本体の実サーバー上での通し動作・データベースへの保存・途中離脱は未確認です。


## Catastrophe loss-assignment fix (2026-11-10)

- `creating_session` writes `num_affected_players` to `Player.loss_condition` in every round.
- When the Round-1 group forms, exactly 0, 2 or 4 affected members are drawn and saved for all 10 rounds.
- If the initial WaitPage callback did not run (e.g. a different Demo path), the first actual slider page performs the assignment as a fallback. The same assignment is reused after reload.
- `calculate_payoffs` checks the assignment so a 2/4 treatment can no longer silently proceed with 0 affected members.
- No database schema change. Create a **new** `catastrophe_loss_2` Demo/session after deploying; previous completed sessions cannot be retroactively corrected.
- This is code-path testing; running a real oTree server with 4 browsers is still necessary before recruitment.


## Update: 2-of-4 affected assignment error (2026-11-10)

A reported `RuntimeError: Invalid catastrophe assignment: expected exactly 2 affected`
was raised when a round-specific Player field did not match the expected
assignment. The group now restores round-specific flags from persistent
`participant.vars` before processing payoffs. This never redraws affected
participants, and explicitly rejects changes in fixed group membership or an
inconsistent stored assignment.

Only `cateffort4_2/__init__.py` and this README have changed. The 7 conditions,
loss at the end of round 5, and Real Effort code are unchanged. Start a new Demo
session after updating; no `resetdb` is needed. Test two affected people by
checking `is_affected_by_catastrophe` in the Round 1 and Round 5 exports,
including `pre_catastrophe_payoff` and `post_catastrophe_payoff`.

This adjustment has been tested using a simulated oTree model but has NOT been
run through an actual oTree server in the present environment.


## 2026-11-10: 2人損失Demoデータ確認後の修正

- `CatastropheStage.html` の損失発生通知から「災害」を削除し、損失前後の累積ポイント表示は維持。
- `Debriefing.html` から災害に関する文言を削除。第5ラウンドのポイント損失はゲーム内の累積得点だけに適用し、最終的な追加報酬の算定には反映しないことを説明。
- カタストロフの `final_cumulative_for_bonus` は損失反映後の `cumulative_payoff` ではなく、各ラウンドの `player.payoff` の合計を保存。通常のCSVにある `participant.payoff` も損失を差し引かない合計。**ゲーム内の累積ポイント (`cumulative_payoff`) には損失を引き続き反映。**
- 整数ポイントを使用するoTreeの中間丸めによって、総拠出6点→還元3点となるケースを確認したため、全4アプリ（両実験の練習・本実験）の公共財還元を `総拠出×1.6÷4` で最後に1回だけ四捨五入する形に変更。総拠出6点→2点。
- **報酬運用上の注意**：カタストロフの `real_world_currency_per_point=0.0` は以前の設定を保持しているため、このプログラムだけでは追加報酬の円換算・支払は行いません。マイボイスコム等への支払い用データでは、実際の報酬算定基準を `participant.payoff`（損失の控除なし）に合わせる必要があります。
- CSVでの検証：セッション`j25fc6iv`は4名×10ラウンド、最終調査票22項目×4名の回答を確認。被害対象2名について第5ラウンドの累積ポイントは43→13、7→2。パスワードはCSV取得時点では未入力。
- 動作検証はローカルの構文チェックと模擬環境によるロジックテストまで。実際のoTreeサーバー上での再実施は必要です。
