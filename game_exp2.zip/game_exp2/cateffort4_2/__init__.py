from otree.api import *
from decimal import Decimal, ROUND_HALF_UP
import random
import time
import re


doc = """
Cateffort4_2: スライダータスクと公共財ゲームを含むメインアプリ
"""

def rounded_share(total_contribution, multiplier, players_per_group):
    """Multiply/divide before rounding to integer points (half up)."""
    raw = (Decimal(str(float(total_contribution)))
           * Decimal(str(multiplier)) / Decimal(players_per_group))
    return int(raw.quantize(Decimal('1'), rounding=ROUND_HALF_UP))


class C(BaseConstants):
    NAME_IN_URL = 'cateffort4_2'
    PLAYERS_PER_GROUP = 4
    NUM_ROUNDS = 10
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10
    MULTIPLIER = 1.6
    CATASTROPHE_ROUND = 5
    CATASTROPHE_FACTOR = 0.3
    TIME_LIMIT = 30
    WAIT_TIMEOUT_SECONDS = 300  # Initial 4-person matching only
    DECISION_TIMEOUT_SECONDS = 300
    RESULT_TIMEOUT_SECONDS = 30




class Subsession(BaseSubsession):
    pass


def group_by_arrival_time_method(subsession, waiting_players):
    # Only Round 1 creates groups; after matching the same four members remain fixed.
    now = time.time()
    key = 'arrival_time_initial_matching'
    for p in waiting_players:
        p.participant.vars.setdefault(key, now)

    active = [p for p in waiting_players
              if now - p.participant.vars[key] <= C.WAIT_TIMEOUT_SECONDS]
    if len(active) >= C.PLAYERS_PER_GROUP:
        return active[:C.PLAYERS_PER_GROUP]

    timed_out = [p for p in waiting_players if p not in active]
    if timed_out:
        return [timed_out[0]]  # Unmatched person exits; no fictitious 4-person group.
    return None

class Group(BaseGroup):
    total_contribution = models.CurrencyField(initial=0)
    individual_share = models.CurrencyField(initial=0)
    group_timed_out = models.BooleanField(initial=False)
    results_ready = models.BooleanField(initial=False)
    wait_started_at = models.FloatField(initial=0)
    cancellation_reason = models.StringField(initial='')


class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    contribution = models.CurrencyField(initial=0)
    cumulative_payoff = models.CurrencyField(initial=0)
    pre_catastrophe_payoff = models.CurrencyField(initial=0)
    post_catastrophe_payoff = models.CurrencyField(initial=0)
    is_affected_by_catastrophe = models.BooleanField(initial=False)
    loss_condition = models.IntegerField(initial=0)  # Number affected in the 4-person group
    decision_timed_out = models.BooleanField(initial=False)
    decision_submitted = models.BooleanField(initial=False)
    group_cancelled = models.BooleanField(initial=False)
    cancelled_at_round = models.IntegerField(initial=0)
    cancellation_reason = models.StringField(initial='')
    site_pass = models.StringField(label='パスワード', max_length=100, blank=False)

    ownership_1 = models.IntegerField(label='そのポイントは、自分のものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_2 = models.IntegerField(label='そのポイントには、「自分のものだ」という強い感覚があった。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_3 = models.IntegerField(label='そのポイントは、自分が所有しているものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_4 = models.IntegerField(label='そのポイントは、自分に属しているものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_5 = models.IntegerField(label='そのポイントには、自分との心理的なつながりを感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_1 = models.IntegerField(label='他のメンバーがポイントを出してくれたことに感謝した。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_2 = models.IntegerField(label='他のメンバーがポイントを出してくれたことを、ありがたいと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_3 = models.IntegerField(label='他のメンバーに対して、感謝の気持ちを感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_1 = models.IntegerField(label='他のメンバーに恩を感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_2 = models.IntegerField(label='他のメンバーに借りができたように感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_3 = models.IntegerField(label='他のメンバーがポイントを出してくれた分、自分もポイントを出して応えなければならないと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_1 = models.IntegerField(label='他のメンバーも、ポイントを出してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_2 = models.IntegerField(label='他のメンバーは、自分のことを考えて行動してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_3 = models.IntegerField(label='自分がポイントを出せば、他のメンバーも同じようにポイントを出してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_1 = models.IntegerField(label='他のメンバーがポイントを出すことは、その人にとって負担のある行動だと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_2 = models.IntegerField(label='他のメンバーは、自分のために残せるポイントを減らしてまで、ポイントを出していると感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_3 = models.IntegerField(label='他のメンバーがポイントを出すことは、その人自身が受け取れるポイントを減らす行動だと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_1 = models.IntegerField(label='ゲームを進めるうちに、どうすれば自分が受け取るポイントを増やせるか分かるようになった。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_2 = models.IntegerField(label='自分が出すポイント数と、最後に自分が受け取るポイント数の関係を理解できた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_3 = models.IntegerField(label='各ラウンドの結果から、次にどう行動すれば自分にとって得になるか予想できた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    manipulation_check_1 = models.IntegerField(label='各ラウンドで使えるポイントは、自分の努力によって得たものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    manipulation_check_2 = models.IntegerField(label='各ラウンドで使えるポイント数は、毎回同じではなく、ラウンドによって変わっていると感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)

for i in range(1, C.SLIDER_TASK_COUNT + 1):
    setattr(Player, f'slider_{i}', models.IntegerField())


# All questionnaire items are shown on one page. Wording and field names are unchanged.
QUESTION_TEXT = {'ownership_1': 'そのポイントは、自分のものだと感じた。', 'ownership_2': 'そのポイントには、「自分のものだ」という強い感覚があった。', 'ownership_3': 'そのポイントは、自分が所有しているものだと感じた。', 'ownership_4': 'そのポイントは、自分に属しているものだと感じた。', 'ownership_5': 'そのポイントには、自分との心理的なつながりを感じた。', 'gratitude_1': '他のメンバーがポイントを出してくれたことに感謝した。', 'gratitude_2': '他のメンバーがポイントを出してくれたことを、ありがたいと感じた。', 'gratitude_3': '他のメンバーに対して、感謝の気持ちを感じた。', 'indebtedness_1': '他のメンバーに恩を感じた。', 'indebtedness_2': '他のメンバーに借りができたように感じた。', 'indebtedness_3': '他のメンバーがポイントを出してくれた分、自分もポイントを出して応えなければならないと感じた。', 'expectations_1': '他のメンバーも、ポイントを出してくれると思っていた。', 'expectations_2': '他のメンバーは、自分のことを考えて行動してくれると思っていた。', 'expectations_3': '自分がポイントを出せば、他のメンバーも同じようにポイントを出してくれると思っていた。', 'cooperation_costs_1': '他のメンバーがポイントを出すことは、その人にとって負担のある行動だと感じた。', 'cooperation_costs_2': '他のメンバーは、自分のために残せるポイントを減らしてまで、ポイントを出していると感じた。', 'cooperation_costs_3': '他のメンバーがポイントを出すことは、その人自身が受け取れるポイントを減らす行動だと感じた。', 'payoff_understanding_1': 'ゲームを進めるうちに、どうすれば自分が受け取るポイントを増やせるか分かるようになった。', 'payoff_understanding_2': '自分が出すポイント数と、最後に自分が受け取るポイント数の関係を理解できた。', 'payoff_understanding_3': '各ラウンドの結果から、次にどう行動すれば自分にとって得になるか予想できた。', 'manipulation_check_1': '各ラウンドで使えるポイントは、自分の努力によって得たものだと感じた。', 'manipulation_check_2': '各ラウンドで使えるポイント数は、毎回同じではなく、ラウンドによって変わっていると感じた。'}
QUESTION_SECTIONS = [('心理的所有感', 'ゲーム中、各ラウンドであなたが使えたポイントについて、どの程度以下のように感じましたか。', ['ownership_1', 'ownership_2', 'ownership_3', 'ownership_4', 'ownership_5']), ('感謝', 'ゲーム中、どの程度以下のように感じましたか。', ['gratitude_1', 'gratitude_2', 'gratitude_3']), ('負債感・返報義務', 'ゲーム中、どの程度以下のように感じましたか。', ['indebtedness_1', 'indebtedness_2', 'indebtedness_3']), ('他者の協力期待', 'ゲーム中、どの程度以下のように考えていましたか。', ['expectations_1', 'expectations_2', 'expectations_3']), ('他者の協力コストの知覚', 'ゲーム中、どの程度以下のように考えていましたか。', ['cooperation_costs_1', 'cooperation_costs_2', 'cooperation_costs_3']), ('利得構造の理解・予測可能性', 'ゲームについて、どの程度以下のように感じましたか。', ['payoff_understanding_1', 'payoff_understanding_2', 'payoff_understanding_3']), ('操作チェック', 'ゲームについて、どの程度以下のように感じましたか。', ['manipulation_check_1', 'manipulation_check_2'])]
QUESTION_FIELDS = [field for _, _, names in QUESTION_SECTIONS for field in names]


def survey_sections(player):
    key = 'catastrophe_survey_order'
    order = player.participant.vars.get(key)
    if order is None:
        order = []
        indices = list(range(len(QUESTION_SECTIONS)))
        random.shuffle(indices)
        for idx in indices:
            section_order = QUESTION_SECTIONS[idx][2][:]
            random.shuffle(section_order)
            order.append([idx, section_order])
        player.participant.vars[key] = order
    return [
        dict(title=QUESTION_SECTIONS[idx][0],
             instruction=QUESTION_SECTIONS[idx][1],
             questions=[dict(field=field, label=QUESTION_TEXT[field]) for field in names])
        for idx, names in order
    ]


def is_cancelled(player):
    return bool(player.participant.vars.get('group_timed_out', False)
                or player.group.group_timed_out)


def cancel_group(group: Group, reason='decision_timeout'):
    # Idempotent: preserve the FIRST cancellation event and its reason.
    if group.group_timed_out:
        return
    group.group_timed_out = True
    group.results_ready = False
    group.cancellation_reason = reason
    for p in group.get_players():
        p.group_cancelled = True
        p.cancelled_at_round = p.round_number
        p.cancellation_reason = reason
        p.participant.vars['group_timed_out'] = True
        p.participant.vars['eligible_for_performance_bonus'] = False
        p.participant.vars.setdefault('cancelled_round', p.round_number)
        p.participant.vars.setdefault('cancellation_reason', reason)


def calculate_payoffs(group: Group):
    players = group.get_players()
    if len(players) != C.PLAYERS_PER_GROUP:
        cancel_group(group, reason='incomplete_group')
        return
    if group.group_timed_out or group.results_ready:
        return
    verify_catastrophe_assignment(group)
    if not all(p.decision_submitted for p in players):
        return

    group.total_contribution = sum(p.contribution for p in players)
    group.individual_share = rounded_share(group.total_contribution, C.MULTIPLIER, C.PLAYERS_PER_GROUP)

    for p in players:
        endowment = p.correct_answers * C.SLIDER_REWARD
        p.payoff = endowment - p.contribution + group.individual_share
        previous_cumulative = p.in_round(p.round_number - 1).cumulative_payoff if p.round_number > 1 else 0
        p.cumulative_payoff = previous_cumulative + p.payoff
        if p.round_number == C.CATASTROPHE_ROUND:
            p.pre_catastrophe_payoff = p.cumulative_payoff
            if p.is_affected_by_catastrophe:
                p.cumulative_payoff *= C.CATASTROPHE_FACTOR
            p.post_catastrophe_payoff = p.cumulative_payoff
        if p.round_number == C.NUM_ROUNDS:
            p.participant.vars['eligible_for_performance_bonus'] = True
            p.participant.vars['final_cumulative_for_bonus'] = sum(float(round_player.payoff) for round_player in p.in_all_rounds())

    group.results_ready = True


def decision_start_key(player):
    # Store the clock per participant/round; do not start it before the decision page is opened.
    return f'{C.NAME_IN_URL}_decision_started_round_{player.round_number}'


def decision_start_time(player):
    # Shared with get_timeout_seconds; reloads must NOT restart the 300s clock.
    key = decision_start_key(player)
    started = player.participant.vars.get(key)
    if started is None:
        started = time.time()
        player.participant.vars[key] = started
    return float(started)


def wait_state(player):
    group = player.group
    if is_cancelled(player):
        return 'cancelled'
    if group.results_ready:
        return 'ready'
    # Two cases: the player opened the decision page (personal 300s), or
    # never reached it because they left on an earlier, auto-advancing page.
    # The latter is capped at 300s from the FIRST submitted contribution.
    now = time.time()
    missing_from_decision_page = []
    for member in group.get_players():
        if member.decision_submitted:
            continue
        started = member.participant.vars.get(decision_start_key(member))
        if started is None:
            missing_from_decision_page.append(member)
        elif now - float(started) >= C.DECISION_TIMEOUT_SECONDS:
            member.decision_timed_out = True
            cancel_group(group, reason='decision_timeout')
            return 'cancelled'
    if (missing_from_decision_page and group.wait_started_at > 0
            and now - group.wait_started_at >= C.DECISION_TIMEOUT_SECONDS):
        # The absent player never opened PublicGoodsGame, so their own 300s
        # countdown cannot run. Do not incorrectly mark that countdown as expired.
        cancel_group(group, reason='decision_not_reached')
        return 'cancelled'
    if len(group.get_players()) == C.PLAYERS_PER_GROUP and all(p.decision_submitted for p in group.get_players()):
        calculate_payoffs(group)
        return 'ready' if group.results_ready else 'cancelled'
    return 'waiting'


def site_pass_error_message(player, value):
    if re.search(r'[\u3040-\u30FF\u4E00-\u9FFF]', value):
        return 'パスワードを正しく入力してください。'

def configured_number_affected(session):
    # Fail visibly if an old or incorrectly configured session is used.
    number = session.config.get('num_affected_players')
    if number not in (0, 2, 4):
        raise ValueError('num_affected_players must be 0, 2, or 4 in settings.py')
    return number


def creating_session(subsession):
    # Session config is known before any participant reaches InitialMatching.
    # Do NOT group participants here: GBAT forms the fixed four-person groups.
    number = configured_number_affected(subsession.session)
    for player in subsession.get_players():
        player.loss_condition = number


def restore_catastrophe_assignment(group: Group):
    """Use the participant-level assignment as the single source of truth.

    Player fields belong to a particular round. They can be out of sync even
    when the persistent participant assignment is intact. Never re-draw here.
    """
    players = group.get_players()
    if len(players) != C.PLAYERS_PER_GROUP:
        return
    number = configured_number_affected(group.session)
    current_codes = sorted(p.participant.code for p in players)

    # Verify the experimental requirement of the same 4 people for all rounds.
    if group.round_number > 1:
        first_group = players[0].in_round(1).group
        original_codes = sorted(p.participant.code for p in first_group.get_players())
        if current_codes != original_codes:
            raise RuntimeError(
                'Fixed group changed in round %s; the catastrophe assignment cannot be reused safely'
                % group.round_number
            )

    affected = []
    for p in players:
        data = p.participant.vars
        if not data.get('catastrophe_assignment_done'):
            raise RuntimeError(
                'Catastrophe assignment missing for participant %s in round %s'
                % (p.id_in_subsession, group.round_number)
            )
        if data.get('catastrophe_condition') != number:
            raise RuntimeError(
                'Catastrophe condition differs from session configuration in round %s'
                % group.round_number
            )
        saved_group = data.get('catastrophe_group_codes')
        if saved_group is not None and sorted(saved_group) != current_codes:
            raise RuntimeError(
                'Catastrophe group membership changed in round %s'
                % group.round_number
            )
        value = data.get('is_affected_by_catastrophe')
        if not isinstance(value, bool):
            raise RuntimeError(
                'Missing or invalid saved catastrophe status in round %s'
                % group.round_number
            )
        affected.append(value)

    if sum(affected) != number:
        raise RuntimeError(
            'Saved catastrophe assignment is inconsistent: round=%s expected=%s saved=%s'
            % (group.round_number, number, sum(affected))
        )

    # Refresh only current-round fields; do not change participant selection.
    # This repairs the discrepancy that previously raised an error when the
    # per-round Player fields and participant.vars differed.
    for p, value in zip(players, affected):
        p.loss_condition = number
        p.is_affected_by_catastrophe = value


def assign_catastrophe_to_fixed_group(group: Group):
    players = group.get_players()
    if len(players) != C.PLAYERS_PER_GROUP:
        cancel_group(group, reason='initial_matching_timeout')
        return
    num_affected = configured_number_affected(group.session)
    already_assigned = [bool(p.participant.vars.get('catastrophe_assignment_done')) for p in players]
    if all(already_assigned):
        # A repeat callback or a page reload must NEVER trigger a second draw.
        restore_catastrophe_assignment(group)
        return
    if any(already_assigned):
        raise RuntimeError('Partial catastrophe assignment: stopping to avoid inconsistent data')

    # The draw is deterministic for this group and cannot change on retries.
    codes = sorted(p.participant.code for p in players)
    seed = '|'.join(codes)
    selected_codes = set(random.Random(seed).sample(codes, num_affected))
    for p in players:
        value = p.participant.code in selected_codes
        p.participant.vars['catastrophe_condition'] = num_affected
        p.participant.vars['is_affected_by_catastrophe'] = value
        p.participant.vars['catastrophe_group_codes'] = codes
        for p_round in p.in_all_rounds():
            p_round.loss_condition = num_affected
            p_round.is_affected_by_catastrophe = value
        p.participant.vars['catastrophe_assignment_done'] = True

    restore_catastrophe_assignment(group)


def verify_catastrophe_assignment(group: Group):
    players = group.get_players()
    if len(players) != C.PLAYERS_PER_GROUP:
        return
    if not all(p.participant.vars.get('catastrophe_assignment_done') for p in players):
        if group.round_number != 1:
            raise RuntimeError(
                'Catastrophe was never assigned in Round 1; round=%s'
                % group.round_number
            )
        assign_catastrophe_to_fixed_group(group)
    # Reconcile from participant.vars before checking the per-round fields.
    restore_catastrophe_assignment(group)


class InitialMatching(WaitPage):
    # Must be the first page in page_sequence to use group_by_arrival_time.
    group_by_arrival_time = True
    title_text = 'メンバーの確定'
    body_text = '4人のメンバーがそろうまでお待ちください。このグループは全10ラウンドを通して固定されます。'

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def after_all_players_arrive(group: Group):
        assign_catastrophe_to_fixed_group(group)


class SliderTask(Page):
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, C.SLIDER_TASK_COUNT + 1)]

    @staticmethod
    def is_displayed(player):
        if is_cancelled(player):
            return False
        if player.round_number == 1:
            # Backup for Demo/alternate navigation that bypassed the GBAT hook.
            # At this point oTree must have formed a fixed group of 4 players.
            verify_catastrophe_assignment(player.group)
        return True

    @staticmethod
    def get_timeout_seconds(player):
        return C.TIME_LIMIT

    @staticmethod
    def js_vars(player):
        return dict(timeout_seconds=C.TIME_LIMIT)

    @staticmethod
    def before_next_page(player, timeout_happened):
        # Slider timeout is NORMAL at the end of the 30-second effort task.
        # Do not classify it as a dropout (even in Round 1).
        player.correct_answers = sum(
            player.field_maybe_none(f'slider_{i}') == 50
            for i in range(1, C.SLIDER_TASK_COUNT + 1)
        )
        player.participant.vars['initial_endowment'] = player.correct_answers * C.SLIDER_REWARD


class SliderResults(Page):
    @staticmethod
    def get_timeout_seconds(player):
        return C.RESULT_TIMEOUT_SECONDS

    @staticmethod
    def is_displayed(player):
        return not is_cancelled(player)

    @staticmethod
    def vars_for_template(player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.participant.vars.get('initial_endowment', 0),
        }


class PublicGoodsGame(Page):
    form_model = 'player'
    form_fields = ['contribution']

    @staticmethod
    def get_timeout_seconds(player):
        # One 300s deadline per participant per round, preserved across page reloads.
        return max(0, C.DECISION_TIMEOUT_SECONDS - (time.time() - decision_start_time(player)))

    @staticmethod
    def is_displayed(player):
        return not is_cancelled(player)

    @staticmethod
    def before_next_page(player, timeout_happened):
        if is_cancelled(player):
            return
        if timeout_happened:
            player.decision_timed_out = True
            cancel_group(player.group, reason='decision_timeout')
        else:
            player.decision_submitted = True
            # Start a group-level rescue clock when the first participant
            # finishes the decision. This is NOT an additional timer for
            # members who have already opened their own decision page.
            if not player.group.wait_started_at:
                player.group.wait_started_at = time.time()
            if all(p.decision_submitted for p in player.group.get_players()):
                calculate_payoffs(player.group)

    @staticmethod
    def vars_for_template(player):
        prev = player.in_round(player.round_number - 1) if player.round_number > 1 else None
        cumulative = prev.cumulative_payoff if prev else 0
        return {
            'round_number': player.round_number,
            'endowment': player.participant.vars.get('initial_endowment', 0),
            'available_points': int(player.participant.vars.get('initial_endowment', 0)),
            'cumulative_payoff': cumulative,
            'is_post_catastrophe': player.round_number > C.CATASTROPHE_ROUND,
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'num_participants': C.PLAYERS_PER_GROUP,
            'show_loss_warning': True,  # All three conditions receive identical loss warnings.
        }


def contribution_error_message(player, value):
    earned = player.correct_answers * C.SLIDER_REWARD
    if not (0 <= value <= earned):
        return f'貢献額は0～{earned}ポイントの範囲で指定してください。'


class ResultsWait(Page):
    # An ordinary live Page avoids an indefinite WaitPage barrier when someone exits.
    @staticmethod
    def is_displayed(player):
        return not is_cancelled(player) and not player.group.results_ready

    # Poll checks personal 300s decision deadlines and the 300s fallback
    # for a member who never reached PublicGoodsGame.
    @staticmethod
    def live_method(player, data):
        return {player.id_in_group: {'status': wait_state(player)}}


class GameResults(Page):
    @staticmethod
    def get_timeout_seconds(player):
        return C.RESULT_TIMEOUT_SECONDS

    @staticmethod
    def is_displayed(player):
        return player.group.results_ready and not is_cancelled(player)

    @staticmethod
    def vars_for_template(player):
        return {
            'round_number': player.round_number,
            'payoff': player.payoff,
            'remain': player.participant.vars.get('initial_endowment', 0) - player.contribution,
            'cumulative_payoff': (player.pre_catastrophe_payoff if player.round_number == C.CATASTROPHE_ROUND else player.cumulative_payoff),
            'group': player.group,
            'num_affected_players': sum(p.is_affected_by_catastrophe for p in player.group.get_players()),
            'contribution': player.contribution,
            'is_affected': player.is_affected_by_catastrophe,
            'is_post_catastrophe': player.round_number > C.CATASTROPHE_ROUND,
        }


class GroupCancelled(Page):
    @staticmethod
    def is_displayed(player):
        return is_cancelled(player) and not player.participant.vars.get('cancellation_notice_seen', False)

    @staticmethod
    def vars_for_template(player):
        round_number = player.participant.vars.get('cancelled_round', player.round_number)
        reason = player.participant.vars.get('cancellation_reason')
        if reason == 'initial_matching_timeout':
            message = '時間内に4人のメンバーが揃わなかったため、実験を終了します。'
        else:
            message = '途中離脱または回答時間の超過により、この4人グループの実験を終了します。'
        return dict(message=message, cancelled_round=round_number,
                    initial_matching_failed=(reason == 'initial_matching_timeout'))

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.participant.vars['cancellation_notice_seen'] = True


class CatastropheStage(Page):
    @staticmethod
    def get_timeout_seconds(player):
        return C.RESULT_TIMEOUT_SECONDS

    @staticmethod
    def is_displayed(player):
        return (player.round_number == C.CATASTROPHE_ROUND
                and player.loss_condition > 0 and not is_cancelled(player))

    @staticmethod
    def vars_for_template(player):
        return {
            'pre_catastrophe_payoff': player.pre_catastrophe_payoff,
            'post_catastrophe_payoff': player.post_catastrophe_payoff,
            'is_affected': player.is_affected_by_catastrophe,
            'num_affected_players': sum(p.is_affected_by_catastrophe for p in player.group.get_players())
        }


class Questionnaire(Page):
    form_model = 'player'
    form_fields = QUESTION_FIELDS

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not is_cancelled(player)

    @staticmethod
    def vars_for_template(player):
        return dict(sections=survey_sections(player), scores=[1, 2, 3, 4, 5, 6, 7])


class Debriefing(Page):
    @staticmethod
    def is_displayed(player):
        # After the questionnaire, including for groups terminated early.
        # Disclosure is deferred so it cannot influence the survey responses.
        return (player.round_number == C.NUM_ROUNDS
                and player.participant.vars.get('cancellation_reason') != 'initial_matching_timeout')


class PasswordEntry(Page):

    @staticmethod
    def is_displayed(player):
        return (
            player.round_number == C.NUM_ROUNDS
            and player.participant.vars.get('cancellation_reason') != 'initial_matching_timeout'
        )

    @staticmethod
    def vars_for_template(player):
        player.participant.vars['completion_code_displayed'] = True
        return dict(
            completion_password='192837465',
        )


class End(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS

    @staticmethod
    def vars_for_template(player):
        return dict(was_cancelled=is_cancelled(player),
                    final_cumulative_points=player.cumulative_payoff,
                    initial_matching_failed=(player.participant.vars.get('cancellation_reason') == 'initial_matching_timeout'))


page_sequence = [
    InitialMatching,
    SliderTask, SliderResults, PublicGoodsGame, ResultsWait,
    GameResults, CatastropheStage, GroupCancelled,
    Questionnaire, Debriefing, PasswordEntry, End,
]

FINAL_PASSWORD_FIELD = 'site_pass'


def vars_for_admin_report(subsession):
    """Status overview for this main app, independent of selected report round.

    Only recorded facts are used: completed rounds, actual survey responses,
    submitted final password, and explicit group-cancellation reasons.  In
    particular, an inactive browser is NOT guessed to be a dropout.
    """
    reason_names = {
        'initial_matching_timeout': '初回マッチング待機超過',
        'decision_timeout': '拠出判断の制限時間超過',
        'decision_not_reached': '拠出判断画面に未到達',
        'round_wait_timeout': '回答待機時間の超過',
        'incomplete_group': '4人グループ不成立',
    }
    counts = dict(normal=0, cancelled=0, matching=0, postgame=0, incomplete=0)
    records = []

    for player in sorted(subsession.get_players(), key=lambda p: p.id_in_subsession):
        participant = player.participant
        rounds = player.in_all_rounds()
        last = rounds[-1]

        completed_rounds = 0
        cancelled_in_round = 0
        saved_reason = participant.vars.get('cancellation_reason') or ''
        group_num = '—'
        has_cancelled_flag = bool(participant.vars.get('group_timed_out'))

        for r in rounds:
            # Before a four-person match, the round-one group may be absent.
            try:
                group = r.group
            except (AttributeError, ValueError):
                group = None
            if r.round_number == 1 and group is not None:
                group_num = group.id_in_subsession or '—'
            if group is not None and group.results_ready:
                completed_rounds += 1
            if r.group_cancelled or (group is not None and group.group_timed_out):
                has_cancelled_flag = True
                if not cancelled_in_round:
                    cancelled_in_round = r.cancelled_at_round or r.round_number
            if not saved_reason:
                saved_reason = (r.cancellation_reason or
                                (group.cancellation_reason if group is not None else '') or '')

        if saved_reason and not cancelled_in_round:
            cancelled_in_round = participant.vars.get('cancelled_round') or 0

        survey_count = sum(
            last.field_maybe_none(field_name) is not None for field_name in QUESTION_FIELDS
        )
        survey_done = survey_count == len(QUESTION_FIELDS)
        # Never display the password itself in an administrative overview.
        password_done = bool(last.field_maybe_none(FINAL_PASSWORD_FIELD))

        if saved_reason == 'initial_matching_timeout':
            status_code, status = 'matching', 'マッチング失敗'
        elif has_cancelled_flag or saved_reason:
            status_code, status = 'cancelled', '途中終了'
        elif completed_rounds == C.NUM_ROUNDS and survey_done and password_done:
            status_code, status = 'normal', '正常完了'
        elif completed_rounds == C.NUM_ROUNDS:
            status_code, status = 'postgame', 'ゲーム完了・事後入力待ち'
        else:
            status_code, status = 'incomplete', '進行中・未完了'
        counts[status_code] += 1

        records.append(dict(
            id_in_subsession=player.id_in_subsession,
            participant_code=participant.code,
            participant_label=participant.label or '—',
            group_num=group_num,
            status=status,
            status_code=status_code,
            completed_rounds=completed_rounds,
            cancellation_round=cancelled_in_round or '—',
            cancellation_reason=(reason_names.get(saved_reason, saved_reason) if saved_reason else '—'),
            questionnaire=f'{survey_count}/{len(QUESTION_FIELDS)}',
            password='入力済' if password_done else '未入力',
        ))

    return dict(
        records=records,
        counts=counts,
        total=len(records),
        experiment_name=subsession.session.config.get('display_name') or C.NAME_IN_URL,
    )
