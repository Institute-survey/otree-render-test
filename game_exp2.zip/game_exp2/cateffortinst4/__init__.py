from otree.api import *
from decimal import Decimal, ROUND_HALF_UP

doc = """
Cateffortinst4: スライダータスクのみのアプリ
"""

def rounded_share(total_contribution, multiplier, players_per_group):
    """Multiply/divide before rounding to integer points (half up)."""
    raw = (Decimal(str(float(total_contribution)))
           * Decimal(str(multiplier)) / Decimal(players_per_group))
    return int(raw.quantize(Decimal('1'), rounding=ROUND_HALF_UP))


class C(BaseConstants):
    NAME_IN_URL = 'cateffortinst4'
    PLAYERS_PER_GROUP = 4  # ここでグループサイズを固定
    NUM_ROUNDS = 1
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10  # スライダータスク正答数に対する倍率
    CATASTROPHE_FACTOR = 0.3
    TIME_LIMIT = 60
    MULTIPLIER = 1.6
    VIRTUAL_CONTRIBUTIONS = 100

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    pass

class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    practice_endowment = models.IntegerField(initial=0)
    practice_contribution = models.CurrencyField(initial=0)
    practice_total_contribution = models.CurrencyField(initial=0)
    practice_individual_share = models.CurrencyField(initial=0)
    practice_payoff = models.CurrencyField(initial=0)

# 50個のスライダーを動的に追加
for i in range(1, C.SLIDER_TASK_COUNT + 1):
    setattr(Player, f'slider_{i}', models.IntegerField())

class InformedConsent(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

class Instruction1(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'num_participants': C.PLAYERS_PER_GROUP,
            'show_loss_warning': True
        }

class SliderTask(Page):
    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, C.SLIDER_TASK_COUNT + 1)]
    
    @staticmethod
    def js_vars(player):
        return dict(
            timeout_seconds=C.TIME_LIMIT
        )

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        player.correct_answers = sum(
            player.field_maybe_none(f'slider_{i}') == 50 for i in range(1, C.SLIDER_TASK_COUNT + 1)
        )
        player.practice_endowment = player.correct_answers * C.SLIDER_REWARD

class SliderResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.correct_answers * C.SLIDER_REWARD
        }
    
class PracticePublicGoodsGame(Page):
    form_model = 'player'
    form_fields = ['practice_contribution']

    @staticmethod
    def vars_for_template(player: Player):
        return {
            'practice_endowment': player.practice_endowment,
            'virtual_contributions': C.VIRTUAL_CONTRIBUTIONS,
            'num_participants': C.PLAYERS_PER_GROUP,
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'show_loss_warning': True,
        }

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        # 仮想プレイヤーの設定値を使う
        others_contribution = C.VIRTUAL_CONTRIBUTIONS * (C.PLAYERS_PER_GROUP - 1)

        player.practice_total_contribution = player.practice_contribution + others_contribution
        player.practice_individual_share = rounded_share(player.practice_total_contribution, C.MULTIPLIER, C.PLAYERS_PER_GROUP)
        player.practice_payoff = player.practice_endowment - player.practice_contribution + player.practice_individual_share


def practice_contribution_error_message(player, value):
    if not (0 <= value <= player.practice_endowment):
        return f'貢献額は0～{player.practice_endowment}ポイントの範囲で指定してください。'


class PracticeResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'practice_contribution': player.practice_contribution,
            'practice_remain': player.practice_endowment - player.practice_contribution,
            'practice_total_contribution': player.practice_total_contribution,
            'practice_individual_share': player.practice_individual_share,
            'practice_payoff': player.practice_payoff,
        }

class Start(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

page_sequence = [InformedConsent, Instruction1, SliderTask, SliderResults, PracticePublicGoodsGame, PracticeResults, Start]
