from otree.api import *
from decimal import Decimal, ROUND_HALF_UP
import random
import time


doc = """
pubeffort: スライダータスクと公共財ゲーム
"""

def rounded_share(total_contribution, multiplier, players_per_group):
    """Multiply/divide before rounding to integer points (half up)."""
    raw = (Decimal(str(float(total_contribution)))
           * Decimal(str(multiplier)) / Decimal(players_per_group))
    return int(raw.quantize(Decimal('1'), rounding=ROUND_HALF_UP))


class C(BaseConstants):
    NAME_IN_URL = 'pubeffort'
    PLAYERS_PER_GROUP = 4
    NUM_ROUNDS = 10
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10
    FIXED_SLIDER_TASK_COUNT = 15
    FIXED_ENDOWMENT = 150
    MULTIPLIER = 1.6
    TIME_LIMIT = 30
    WAIT_TIMEOUT_SECONDS = 300  # Initial 4-person matching only
    RESULTS_PAGE_TIMEOUT_SECONDS = 120
    DECISION_TIMEOUT_SECONDS = 300


def get_condition(player):
    condition = player.session.config.get('condition', 'effort_variable')
    if condition not in ('effort_variable', 'no_effort_variable',
                         'effort_fixed', 'no_effort_fixed'):
        raise ValueError(f'Unknown experimental condition: {condition}')
    return condition


def has_effort(player):
    return get_condition(player).startswith('effort_')


def is_variable(player):
    return get_condition(player).endswith('_variable')


def slider_count(player):
    return C.SLIDER_TASK_COUNT if is_variable(player) else C.FIXED_SLIDER_TASK_COUNT




class Subsession(BaseSubsession):
    pass


def group_by_arrival_time_method(subsession, waiting_players):
    now = time.time()
    required = C.PLAYERS_PER_GROUP
    round_key = 'arrival_time_round_1'

    for p in waiting_players:
        if round_key not in p.participant.vars:
            p.participant.vars[round_key] = now

    timeout_players = []
    not_timeout_players = []
    for p in waiting_players:
        arrival_time = p.participant.vars[round_key]
        elapsed = now - arrival_time
        if elapsed > C.WAIT_TIMEOUT_SECONDS:
            timeout_players.append(p)
        else:
            not_timeout_players.append(p)

    if len(not_timeout_players) >= required:
        return not_timeout_players[:required]
    if timeout_players:
        p = timeout_players[0]
        p.group_cancelled = True
        p.cancelled_at_round = p.round_number
        p.cancellation_reason = 'initial_matching_timeout'
        p.participant.vars['cancellation_reason'] = 'initial_matching_timeout'
        p.participant.vars['cancelled_round'] = p.round_number
        p.participant.vars['group_timed_out'] = True
        p.participant.vars['eligible_for_performance_bonus'] = False
        return [p]
    return None


class Group(BaseGroup):
    total_contribution = models.CurrencyField(initial=0)
    individual_share = models.CurrencyField(initial=0)
    group_timed_out = models.BooleanField(initial=False)
    results_ready = models.BooleanField(initial=False)
    wait_started_at = models.FloatField(initial=0)
    cancellation_reason = models.StringField(initial="")


class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    contribution = models.CurrencyField(initial=0)
    cumulative_payoff = models.CurrencyField(initial=0)
    endowment = models.CurrencyField(initial=0)
    experimental_condition = models.StringField()
    control_4_source_id = models.IntegerField(initial=0)
    decision_submitted = models.BooleanField(initial=False)
    decision_timeout = models.BooleanField(initial=False)
    group_cancelled = models.BooleanField(initial=False)
    cancelled_at_round = models.IntegerField(initial=0)
    cancellation_reason = models.StringField(initial='')
    completion_password = models.StringField(label='パスワード', max_length=100)

    ownership_1 = models.IntegerField(label='そのポイントは、自分のものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_2 = models.IntegerField(label='そのポイントには、「自分のものだ」という強い感覚があった。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_3 = models.IntegerField(label='そのポイントは、自分が所有しているものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_4 = models.IntegerField(label='そのポイントは、自分に属しているものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_5 = models.IntegerField(label='そのポイントには、自分との心理的なつながりを感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_1 = models.IntegerField(label='他のメンバーがポイントを出してくれたことに感謝した。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_2 = models.IntegerField(label='他のメンバーがポイントを出してくれたことを、ありがたいと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_3 = models.IntegerField(label='他のメンバーに対して、感謝の気持ちを感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_1 = models.IntegerField(label='他のメンバーに恩を感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_2 = models.IntegerField(label='他のメンバーに借りができたように感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_3 = models.IntegerField(label='他のメンバーがポイントを出してくれた分、自分もポイントを出して応えなければならないと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_1 = models.IntegerField(label='他のメンバーも、ポイントを出してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_2 = models.IntegerField(label='他のメンバーは、自分のことを考えて行動してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_3 = models.IntegerField(label='自分がポイントを出せば、他のメンバーも同じようにポイントを出してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_1 = models.IntegerField(label='他のメンバーがポイントを出すことは、その人にとって負担のある行動だと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_2 = models.IntegerField(label='他のメンバーは、自分のために残せるポイントを減らしてまで、ポイントを出していると感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_3 = models.IntegerField(label='他のメンバーがポイントを出すことは、その人自身が受け取れるポイントを減らす行動だと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_1 = models.IntegerField(label='ゲームを進めるうちに、どうすれば自分が受け取るポイントを増やせるか分かるようになった。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_2 = models.IntegerField(label='自分が出すポイント数と、最後に自分が受け取るポイント数の関係を理解できた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_3 = models.IntegerField(label='各ラウンドの結果から、次にどう行動すれば自分にとって得になるか予想できた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    manipulation_check_1 = models.IntegerField(label='各ラウンドで使えるポイントは、自分の努力によって得たものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    manipulation_check_2 = models.IntegerField(label='各ラウンドで使えるポイント数は、毎回同じではなく、ラウンドによって変わっていると感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)

    slider_1 = models.IntegerField(blank=True)
    slider_2 = models.IntegerField(blank=True)
    slider_3 = models.IntegerField(blank=True)
    slider_4 = models.IntegerField(blank=True)
    slider_5 = models.IntegerField(blank=True)
    slider_6 = models.IntegerField(blank=True)
    slider_7 = models.IntegerField(blank=True)
    slider_8 = models.IntegerField(blank=True)
    slider_9 = models.IntegerField(blank=True)
    slider_10 = models.IntegerField(blank=True)
    slider_11 = models.IntegerField(blank=True)
    slider_12 = models.IntegerField(blank=True)
    slider_13 = models.IntegerField(blank=True)
    slider_14 = models.IntegerField(blank=True)
    slider_15 = models.IntegerField(blank=True)
    slider_16 = models.IntegerField(blank=True)
    slider_17 = models.IntegerField(blank=True)
    slider_18 = models.IntegerField(blank=True)
    slider_19 = models.IntegerField(blank=True)
    slider_20 = models.IntegerField(blank=True)
    slider_21 = models.IntegerField(blank=True)
    slider_22 = models.IntegerField(blank=True)
    slider_23 = models.IntegerField(blank=True)
    slider_24 = models.IntegerField(blank=True)
    slider_25 = models.IntegerField(blank=True)
    slider_26 = models.IntegerField(blank=True)
    slider_27 = models.IntegerField(blank=True)
    slider_28 = models.IntegerField(blank=True)
    slider_29 = models.IntegerField(blank=True)
    slider_30 = models.IntegerField(blank=True)
    slider_31 = models.IntegerField(blank=True)
    slider_32 = models.IntegerField(blank=True)
    slider_33 = models.IntegerField(blank=True)
    slider_34 = models.IntegerField(blank=True)
    slider_35 = models.IntegerField(blank=True)
    slider_36 = models.IntegerField(blank=True)
    slider_37 = models.IntegerField(blank=True)
    slider_38 = models.IntegerField(blank=True)
    slider_39 = models.IntegerField(blank=True)
    slider_40 = models.IntegerField(blank=True)
    slider_41 = models.IntegerField(blank=True)
    slider_42 = models.IntegerField(blank=True)
    slider_43 = models.IntegerField(blank=True)
    slider_44 = models.IntegerField(blank=True)
    slider_45 = models.IntegerField(blank=True)
    slider_46 = models.IntegerField(blank=True)
    slider_47 = models.IntegerField(blank=True)
    slider_48 = models.IntegerField(blank=True)
    slider_49 = models.IntegerField(blank=True)
    slider_50 = models.IntegerField(blank=True)


# All questionnaire items are shown on one page. Wording and field names are unchanged.
QUESTION_TEXT = {'ownership_1': 'そのポイントは、自分のものだと感じた。', 'ownership_2': 'そのポイントには、「自分のものだ」という強い感覚があった。', 'ownership_3': 'そのポイントは、自分が所有しているものだと感じた。', 'ownership_4': 'そのポイントは、自分に属しているものだと感じた。', 'ownership_5': 'そのポイントには、自分との心理的なつながりを感じた。', 'gratitude_1': '他のメンバーがポイントを出してくれたことに感謝した。', 'gratitude_2': '他のメンバーがポイントを出してくれたことを、ありがたいと感じた。', 'gratitude_3': '他のメンバーに対して、感謝の気持ちを感じた。', 'indebtedness_1': '他のメンバーに恩を感じた。', 'indebtedness_2': '他のメンバーに借りができたように感じた。', 'indebtedness_3': '他のメンバーがポイントを出してくれた分、自分もポイントを出して応えなければならないと感じた。', 'expectations_1': '他のメンバーも、ポイントを出してくれると思っていた。', 'expectations_2': '他のメンバーは、自分のことを考えて行動してくれると思っていた。', 'expectations_3': '自分がポイントを出せば、他のメンバーも同じようにポイントを出してくれると思っていた。', 'cooperation_costs_1': '他のメンバーがポイントを出すことは、その人にとって負担のある行動だと感じた。', 'cooperation_costs_2': '他のメンバーは、自分のために残せるポイントを減らしてまで、ポイントを出していると感じた。', 'cooperation_costs_3': '他のメンバーがポイントを出すことは、その人自身が受け取れるポイントを減らす行動だと感じた。', 'payoff_understanding_1': 'ゲームを進めるうちに、どうすれば自分が受け取るポイントを増やせるか分かるようになった。', 'payoff_understanding_2': '自分が出すポイント数と、最後に自分が受け取るポイント数の関係を理解できた。', 'payoff_understanding_3': '各ラウンドの結果から、次にどう行動すれば自分にとって得になるか予想できた。', 'manipulation_check_1': '各ラウンドで使えるポイントは、自分の努力によって得たものだと感じた。', 'manipulation_check_2': '各ラウンドで使えるポイント数は、毎回同じではなく、ラウンドによって変わっていると感じた。'}
QUESTION_SECTIONS = [('心理的所有感', 'ゲーム中、各ラウンドであなたが使えたポイントについて、どの程度以下のように感じましたか。', ['ownership_1', 'ownership_2', 'ownership_3', 'ownership_4', 'ownership_5']), ('感謝', 'ゲーム中、どの程度以下のように感じましたか。', ['gratitude_1', 'gratitude_2', 'gratitude_3']), ('負債感・返報義務', 'ゲーム中、どの程度以下のように感じましたか。', ['indebtedness_1', 'indebtedness_2', 'indebtedness_3']), ('他者の協力期待', 'ゲーム中、どの程度以下のように考えていましたか。', ['expectations_1', 'expectations_2', 'expectations_3']), ('他者の協力コストの知覚', 'ゲーム中、どの程度以下のように考えていましたか。', ['cooperation_costs_1', 'cooperation_costs_2', 'cooperation_costs_3']), ('利得構造の理解・予測可能性', 'ゲームについて、どの程度以下のように感じましたか。', ['payoff_understanding_1', 'payoff_understanding_2', 'payoff_understanding_3']), ('操作チェック', 'ゲームについて、どの程度以下のように感じましたか。', ['manipulation_check_1', 'manipulation_check_2'])]
QUESTION_FIELDS = [field for _, _, names in QUESTION_SECTIONS for field in names]


def survey_sections(player):
    key = 'realeffort_survey_order'
    order = player.participant.vars.get(key)
    if order is None:
        order = []
        indices = list(range(len(QUESTION_SECTIONS)))
        random.shuffle(indices)
        for idx in indices:
            section_order = QUESTION_SECTIONS[idx][2][:]
            random.shuffle(section_order)
            order.append([idx, section_order])
        player.participant.vars[key] = order
    return [
        dict(title=QUESTION_SECTIONS[idx][0],
             instruction=QUESTION_SECTIONS[idx][1],
             questions=[dict(field=field, label=QUESTION_TEXT[field]) for field in names])
        for idx, names in order
    ]


def creating_session(subsession):
    condition = subsession.session.config.get('condition', 'effort_variable')
    for player in subsession.get_players():
        player.experimental_condition = condition
        if condition == 'no_effort_variable':
            # One randomized control_4 history is shared across this player's 10 rounds.
            player.endowment = player.participant.vars['control_4_endowments'][subsession.round_number - 1]
            player.control_4_source_id = player.participant.vars['control_4_source_id']
        elif condition == 'no_effort_fixed':
            player.endowment = C.FIXED_ENDOWMENT

def cancel_group(group: Group, reason='timeout'):
    # Idempotent; keep the first cancellation reason and do not pay an unfinished round.
    if group.group_timed_out:
        return
    group.group_timed_out = True
    group.cancellation_reason = reason
    group.results_ready = False
    for p in group.get_players():
        p.group_cancelled = True
        p.cancelled_at_round = p.round_number
        p.cancellation_reason = reason
        p.participant.vars['group_timed_out'] = True
        p.participant.vars.setdefault('cancelled_round', p.round_number)
        p.participant.vars.setdefault('cancellation_reason', reason)


def calculate_payoffs(group: Group):
    players = group.get_players()
    if len(players) != C.PLAYERS_PER_GROUP:
        cancel_group(group, reason='incomplete_group')
        return
    if group.group_timed_out or group.results_ready:
        return
    if not all(p.decision_submitted for p in players):
        return

    group.total_contribution = sum(p.contribution for p in players)
    group.individual_share = rounded_share(group.total_contribution, C.MULTIPLIER, C.PLAYERS_PER_GROUP)

    for p in players:
        endowment = p.endowment
        p.payoff = endowment - p.contribution + group.individual_share
        if p.round_number == 1:
            p.cumulative_payoff = p.payoff
        else:
            previous = p.in_round(p.round_number - 1)
            p.cumulative_payoff = previous.cumulative_payoff + p.payoff
    group.results_ready = True
    if group.get_players()[0].round_number == C.NUM_ROUNDS:
        for p in players:
            p.participant.vars['eligible_for_performance_bonus'] = True
            p.participant.vars['final_cumulative_for_bonus'] = float(p.cumulative_payoff)


def is_cancelled(player):
    return player.participant.vars.get('group_timed_out', False) or player.group.group_timed_out


def decision_start_key(player):
    # Store the clock per participant/round; do not start it before the decision page is opened.
    return f'{C.NAME_IN_URL}_decision_started_round_{player.round_number}'


def decision_start_time(player):
    # Shared with get_timeout_seconds; reloads must NOT restart the 300s clock.
    key = decision_start_key(player)
    started = player.participant.vars.get(key)
    if started is None:
        started = time.time()
        player.participant.vars[key] = started
    return float(started)


def wait_state(player):
    group = player.group
    if is_cancelled(player):
        return 'cancelled'
    if group.results_ready:
        return 'ready'
    # Two cases: the player opened the decision page (personal 300s), or
    # never reached it because they left on an earlier, auto-advancing page.
    # The latter is capped at 300s from the FIRST submitted contribution.
    now = time.time()
    missing_from_decision_page = []
    for member in group.get_players():
        if member.decision_submitted:
            continue
        started = member.participant.vars.get(decision_start_key(member))
        if started is None:
            missing_from_decision_page.append(member)
        elif now - float(started) >= C.DECISION_TIMEOUT_SECONDS:
            member.decision_timeout = True
            cancel_group(group, reason='decision_timeout')
            return 'cancelled'
    if (missing_from_decision_page and group.wait_started_at > 0
            and now - group.wait_started_at >= C.DECISION_TIMEOUT_SECONDS):
        # The absent player never opened PublicGoodsGame, so their own 300s
        # countdown cannot run. Do not incorrectly mark that countdown as expired.
        cancel_group(group, reason='decision_not_reached')
        return 'cancelled'
    players = group.get_players()
    if all(p.decision_submitted for p in players) and len(players) == C.PLAYERS_PER_GROUP:
        calculate_payoffs(group)
        return 'ready' if group.results_ready else 'cancelled'
    return 'waiting'

class InitialGroupWaitPage(WaitPage):
    group_by_arrival_time = True
    title_text = 'メンバーの確定'
    body_text = '4人のメンバーがそろうまでお待ちください。このグループは全10ラウンドを通して固定されます。'

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def after_all_players_arrive(group: Group):
        if len(group.get_players()) < C.PLAYERS_PER_GROUP:
            cancel_group(group, reason='initial_matching_timeout')


class SliderTask(Page):
    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'

    @staticmethod
    def is_displayed(player):
        return has_effort(player) and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def get_form_fields(player):
        return [f'slider_{i}' for i in range(1, slider_count(player) + 1)]

    @staticmethod
    def js_vars(player):
        return dict(timeout_seconds=C.TIME_LIMIT, slider_count=slider_count(player))

    @staticmethod
    def vars_for_template(player):
        return dict(slider_count=slider_count(player),
                    slider_indices=range(1, slider_count(player) + 1))

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.correct_answers = sum(
            player.field_maybe_none(f'slider_{i}') == 50 for i in range(1, slider_count(player) + 1)
        )
        player.endowment = (player.correct_answers * C.SLIDER_REWARD
                            if is_variable(player) else C.FIXED_ENDOWMENT)
        player.participant.vars['initial_endowment'] = player.endowment


class SliderResults(Page):
    timeout_seconds = C.RESULTS_PAGE_TIMEOUT_SECONDS

    @staticmethod
    def is_displayed(player):
        return has_effort(player) and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.endowment,
            'is_variable': is_variable(player),
        }


def contribution_error_message(player, value):
    if value < 0 or value > player.endowment:
        return f'貢献額は0から{player.endowment}ポイントの範囲で入力してください。'


class PublicGoodsGame(Page):
    form_model = 'player'
    form_fields = ['contribution']
    @staticmethod
    def get_timeout_seconds(player):
        # One 300s deadline per participant per round, preserved across page reloads.
        return max(0, C.DECISION_TIMEOUT_SECONDS - (time.time() - decision_start_time(player)))

    @staticmethod
    def before_next_page(player, timeout_happened):
        if is_cancelled(player):
            return
        if timeout_happened:
            player.decision_timeout = True
            cancel_group(player.group, reason='decision_timeout')
        else:
            player.decision_submitted = True
            # Start a group-level rescue clock when the first participant
            # finishes the decision. This is NOT an additional timer for
            # members who have already opened their own decision page.
            if not player.group.wait_started_at:
                player.group.wait_started_at = time.time()
            if all(p.decision_submitted for p in player.group.get_players()):
                calculate_payoffs(player.group)

    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        prev = player.in_round(player.round_number - 1) if player.round_number > 1 else None
        cumulative = prev.cumulative_payoff if prev else 0
        return {
            'round_number': player.round_number,
            'endowment': player.endowment,
            'available_points': int(player.endowment),
            'cumulative_payoff': cumulative,
            'num_participants': C.PLAYERS_PER_GROUP,
            'has_effort': has_effort(player),
            'is_variable': is_variable(player),
            'example_endowment': 20 if is_variable(player) else 150,
            'example_payoff_15': 17 if is_variable(player) else 147,
            'example_payoff_5': 27 if is_variable(player) else 157,
        }


class ResultsWait(Page):
    # A regular Page is used instead of WaitPage so active members are never
    # trapped by a member who closed the browser (also on devserver).
    @staticmethod
    def is_displayed(player):
        return not is_cancelled(player) and not player.group.results_ready

    # Poll checks personal 300s decision deadlines and the 300s fallback
    # for a member who never reached PublicGoodsGame.
    @staticmethod
    def live_method(player, data):
        return {player.id_in_group: {'status': wait_state(player)}}


class GameResults(Page):
    timeout_seconds = C.RESULTS_PAGE_TIMEOUT_SECONDS

    @staticmethod
    def is_displayed(player):
        return player.group.results_ready and not is_cancelled(player)

    @staticmethod
    def vars_for_template(player):
        return {
            'round_number': player.round_number,
            'payoff': player.payoff,
            'remain': player.endowment - player.contribution,
            'cumulative_payoff': player.cumulative_payoff,
            'group': player.group,
            'contribution': player.contribution,
        }


class GroupCancelled(Page):
    @staticmethod
    def is_displayed(player):
        return is_cancelled(player) and not player.participant.vars.get('cancellation_notice_seen', False)

    @staticmethod
    def vars_for_template(player):
        reason = player.participant.vars.get('cancellation_reason')
        initial_matching_failed = reason == 'initial_matching_timeout'
        if initial_matching_failed:
            message = '300秒以内に4人の参加者が揃わなかったため、ゲームを開始できませんでした。'
        else:
            message = '参加者の途中離脱または待機時間の超過により、このグループのゲームを終了します。'
        return dict(
            message=message,
            cancelled_round=player.participant.vars.get('cancelled_round', player.round_number),
            initial_matching_failed=initial_matching_failed,
        )

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.participant.vars['cancellation_notice_seen'] = True


class Questionnaire(Page):
    form_model = 'player'
    form_fields = QUESTION_FIELDS

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not is_cancelled(player)

    @staticmethod
    def vars_for_template(player):
        return dict(sections=survey_sections(player), scores=[1, 2, 3, 4, 5, 6, 7])


class CompletionPassword(Page):

    @staticmethod
    def is_displayed(player):
        return (
            player.round_number == C.NUM_ROUNDS
            and player.participant.vars.get('cancellation_reason') != 'initial_matching_timeout'
        )

    @staticmethod
    def vars_for_template(player):
        player.participant.vars['completion_code_displayed'] = True
        return dict(
            completion_password='192837465',
        )



class Complete(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS

    @staticmethod
    def vars_for_template(player):
        return dict(initial_matching_failed=(player.participant.vars.get('cancellation_reason') == 'initial_matching_timeout'))


page_sequence = [
    InitialGroupWaitPage,
    SliderTask, SliderResults, PublicGoodsGame,
    ResultsWait, GameResults, GroupCancelled,
    Questionnaire, CompletionPassword, Complete,
]

FINAL_PASSWORD_FIELD = 'completion_password'


def vars_for_admin_report(subsession):
    """Status overview for this main app, independent of selected report round.

    Only recorded facts are used: completed rounds, actual survey responses,
    submitted final password, and explicit group-cancellation reasons.  In
    particular, an inactive browser is NOT guessed to be a dropout.
    """
    reason_names = {
        'initial_matching_timeout': '初回マッチング待機超過',
        'decision_timeout': '拠出判断の制限時間超過',
        'decision_not_reached': '拠出判断画面に未到達',
        'round_wait_timeout': '回答待機時間の超過',
        'incomplete_group': '4人グループ不成立',
    }
    counts = dict(normal=0, cancelled=0, matching=0, postgame=0, incomplete=0)
    records = []

    for player in sorted(subsession.get_players(), key=lambda p: p.id_in_subsession):
        participant = player.participant
        rounds = player.in_all_rounds()
        last = rounds[-1]

        completed_rounds = 0
        cancelled_in_round = 0
        saved_reason = participant.vars.get('cancellation_reason') or ''
        group_num = '—'
        has_cancelled_flag = bool(participant.vars.get('group_timed_out'))

        for r in rounds:
            # Before a four-person match, the round-one group may be absent.
            try:
                group = r.group
            except (AttributeError, ValueError):
                group = None
            if r.round_number == 1 and group is not None:
                group_num = group.id_in_subsession or '—'
            if group is not None and group.results_ready:
                completed_rounds += 1
            if r.group_cancelled or (group is not None and group.group_timed_out):
                has_cancelled_flag = True
                if not cancelled_in_round:
                    cancelled_in_round = r.cancelled_at_round or r.round_number
            if not saved_reason:
                saved_reason = (r.cancellation_reason or
                                (group.cancellation_reason if group is not None else '') or '')

        if saved_reason and not cancelled_in_round:
            cancelled_in_round = participant.vars.get('cancelled_round') or 0

        survey_count = sum(
            last.field_maybe_none(field_name) is not None for field_name in QUESTION_FIELDS
        )
        survey_done = survey_count == len(QUESTION_FIELDS)
        # Never display the password itself in an administrative overview.
        password_done = bool(last.field_maybe_none(FINAL_PASSWORD_FIELD))

        if saved_reason == 'initial_matching_timeout':
            status_code, status = 'matching', 'マッチング失敗'
        elif has_cancelled_flag or saved_reason:
            status_code, status = 'cancelled', '途中終了'
        elif completed_rounds == C.NUM_ROUNDS and survey_done and password_done:
            status_code, status = 'normal', '正常完了'
        elif completed_rounds == C.NUM_ROUNDS:
            status_code, status = 'postgame', 'ゲーム完了・事後入力待ち'
        else:
            status_code, status = 'incomplete', '進行中・未完了'
        counts[status_code] += 1

        records.append(dict(
            id_in_subsession=player.id_in_subsession,
            participant_code=participant.code,
            participant_label=participant.label or '—',
            group_num=group_num,
            status=status,
            status_code=status_code,
            completed_rounds=completed_rounds,
            cancellation_round=cancelled_in_round or '—',
            cancellation_reason=(reason_names.get(saved_reason, saved_reason) if saved_reason else '—'),
            questionnaire=f'{survey_count}/{len(QUESTION_FIELDS)}',
            password='入力済' if password_done else '未入力',
        ))

    return dict(
        records=records,
        counts=counts,
        total=len(records),
        experiment_name=subsession.session.config.get('display_name') or C.NAME_IN_URL,
    )
