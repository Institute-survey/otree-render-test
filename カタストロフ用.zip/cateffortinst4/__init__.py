from otree.api import *
import re

doc = """
Cateffortinst4: スライダータスクのみのアプリ
"""

class C(BaseConstants):
    NAME_IN_URL = 'cateffortinst4'
    PLAYERS_PER_GROUP = 4  # ここでグループサイズを固定
    NUM_ROUNDS = 1
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10  # スライダータスク正答数に対する倍率
    CATASTROPHE_FACTOR = 0.3
    TIME_LIMIT = 60
    MULTIPLIER = 1.6
    VIRTUAL_CONTRIBUTIONS = 100

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    pass

class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    practice_endowment = models.IntegerField(initial=0)
    practice_contribution = models.CurrencyField(initial=0)
    practice_total_contribution = models.CurrencyField(initial=0)
    practice_individual_share = models.CurrencyField(initial=0)
    practice_payoff = models.CurrencyField(initial=0)
    site_id = models.StringField(
        label="あなたのユーザIDを入力してください",
        max_length=5
    )
    site_pass = models.StringField(
        label="パスワードを入力してください"
    )

# ✅ site_id: 半角英数字・記号はOK、日本語文字は禁止
def site_id_error_message(player, value):
    if re.search(r'[\u3040-\u30FF\u4E00-\u9FFF]', value):
        return 'IDは半角英数字で入力してください'
    if len(value) > 5:
        return 'IDは5文字以内で入力してください'


# ✅ site_pass: 同様に日本語のみ禁止
def site_pass_error_message(player, value):
    if re.search(r'[\u3040-\u30FF\u4E00-\u9FFF]', value):
        return 'パスワードを正しく入力してください'

# 50個のスライダーを動的に追加
for i in range(1, C.SLIDER_TASK_COUNT + 1):
    setattr(Player, f'slider_{i}', models.IntegerField())

class InformedConsent(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

class Information(Page):
    form_model = 'player'
    form_fields = ['site_id', 'site_pass']

class Instruction1(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'num_participants': C.PLAYERS_PER_GROUP,
            'show_loss_warning': int(player.session.config.get('num_affected_players', 0)) > 0
        }

class SliderTask(Page):
    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, C.SLIDER_TASK_COUNT + 1)]
    
    @staticmethod
    def js_vars(player):
        return dict(
            timeout_seconds=C.TIME_LIMIT
        )

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        player.correct_answers = sum(
            getattr(player, f'slider_{i}') == 50 for i in range(1, C.SLIDER_TASK_COUNT + 1)
        )
        player.practice_endowment = player.correct_answers * C.SLIDER_REWARD

class SliderResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.correct_answers * C.SLIDER_REWARD
        }
    
class PracticePublicGoodsGame(Page):
    form_model = 'player'
    form_fields = ['practice_contribution']

    @staticmethod
    def vars_for_template(player: Player):
        return {
            'practice_endowment': player.practice_endowment,
            'virtual_contributions': C.VIRTUAL_CONTRIBUTIONS,
            'num_participants': C.PLAYERS_PER_GROUP,
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'show_loss_warning': int(player.session.config.get('num_affected_players', 0)) > 0,
        }

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        # 仮想プレイヤーの設定値を使う
        others_contribution = C.VIRTUAL_CONTRIBUTIONS * (C.PLAYERS_PER_GROUP - 1)

        player.practice_total_contribution = player.practice_contribution + others_contribution
        player.practice_individual_share = (player.practice_total_contribution * C.MULTIPLIER) / C.PLAYERS_PER_GROUP
        player.practice_payoff = player.practice_endowment - player.practice_contribution + player.practice_individual_share


def practice_contribution_error_message(player, value):
    if not (0 <= value <= player.practice_endowment):
        return f'貢献額は0～{player.practice_endowment}ポイントの範囲で指定してください。'


class PracticeResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'practice_contribution': player.practice_contribution,
            'practice_remain': player.practice_endowment - player.practice_contribution,
            'practice_total_contribution': player.practice_total_contribution,
            'practice_individual_share': player.practice_individual_share,
            'practice_payoff': player.practice_payoff,
        }

class Start(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

page_sequence = [InformedConsent, Information, Instruction1, SliderTask, SliderResults, PracticePublicGoodsGame, PracticeResults, Start]
