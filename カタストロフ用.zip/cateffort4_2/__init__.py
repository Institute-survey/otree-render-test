from otree.api import *
import random
import time


doc = """
Cateffort4_2: スライダータスクと公共財ゲームを含むメインアプリ
"""

class C(BaseConstants):
    NAME_IN_URL = 'cateffort4_2'
    PLAYERS_PER_GROUP = 4
    NUM_ROUNDS = 10
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10
    MULTIPLIER = 1.6
    CATASTROPHE_ROUND = 5
    CATASTROPHE_FACTOR = 0.3
    TIME_LIMIT = 30
    WAIT_TIMEOUT_SECONDS = 300  


class Subsession(BaseSubsession):
    pass


def group_by_arrival_time_method(subsession, waiting_players):
    # Only used at the initial matching page (Round 1). oTree keeps the group
    # composition for subsequent rounds when GBAT runs exclusively in Round 1.
    now = time.time()
    arrival_key = 'arrival_time_initial_matching'
    for p in waiting_players:
        if arrival_key not in p.participant.vars:
            p.participant.vars[arrival_key] = now

    if len(waiting_players) >= C.PLAYERS_PER_GROUP:
        return waiting_players[:C.PLAYERS_PER_GROUP]

    # Retain the original fallback for a participant whose queue time has elapsed.
    # As in the original code, this check runs when an arrival triggers the callback.
    for p in waiting_players:
        if now - p.participant.vars[arrival_key] > C.WAIT_TIMEOUT_SECONDS:
            p.participant.vars['group_timed_out'] = True
            return [p]

    return None


class Group(BaseGroup):
    total_contribution = models.CurrencyField(initial=0)
    individual_share = models.CurrencyField(initial=0)
    group_timed_out = models.BooleanField(initial=False)


class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    contribution = models.CurrencyField(initial=0)
    cumulative_payoff = models.CurrencyField(initial=0)
    pre_catastrophe_payoff = models.CurrencyField(initial=0)
    post_catastrophe_payoff = models.CurrencyField(initial=0)
    is_affected_by_catastrophe = models.BooleanField(initial=False)
    loss_condition = models.IntegerField(initial=0)  # Number affected in the 4-person group

    ownership_1 = models.IntegerField(label='そのポイントは、自分のものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_2 = models.IntegerField(label='そのポイントには、「自分のものだ」という強い感覚があった。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_3 = models.IntegerField(label='そのポイントは、自分が所有しているものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_4 = models.IntegerField(label='そのポイントは、自分に属しているものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    ownership_5 = models.IntegerField(label='そのポイントには、自分との心理的なつながりを感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_1 = models.IntegerField(label='他のメンバーがポイントを出してくれたことに感謝した。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_2 = models.IntegerField(label='他のメンバーがポイントを出してくれたことを、ありがたいと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    gratitude_3 = models.IntegerField(label='他のメンバーに対して、感謝の気持ちを感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_1 = models.IntegerField(label='他のメンバーに恩を感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_2 = models.IntegerField(label='他のメンバーに借りができたように感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    indebtedness_3 = models.IntegerField(label='他のメンバーがポイントを出してくれた分、自分もポイントを出して応えなければならないと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_1 = models.IntegerField(label='他のメンバーも、ポイントを出してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_2 = models.IntegerField(label='他のメンバーは、自分のことを考えて行動してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    expectations_3 = models.IntegerField(label='自分がポイントを出せば、他のメンバーも同じようにポイントを出してくれると思っていた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_1 = models.IntegerField(label='他のメンバーがポイントを出すことは、その人にとって負担のある行動だと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_2 = models.IntegerField(label='他のメンバーは、自分のために残せるポイントを減らしてまで、ポイントを出していると感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    cooperation_costs_3 = models.IntegerField(label='他のメンバーがポイントを出すことは、その人自身が受け取れるポイントを減らす行動だと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_1 = models.IntegerField(label='ゲームを進めるうちに、どうすれば自分が受け取るポイントを増やせるか分かるようになった。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_2 = models.IntegerField(label='自分が出すポイント数と、最後に自分が受け取るポイント数の関係を理解できた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    payoff_understanding_3 = models.IntegerField(label='各ラウンドの結果から、次にどう行動すれば自分にとって得になるか予想できた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    manipulation_check_1 = models.IntegerField(label='各ラウンドで使えるポイントは、自分の努力によって得たものだと感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)
    manipulation_check_2 = models.IntegerField(label='各ラウンドで使えるポイント数は、毎回同じではなく、ラウンドによって変わっていると感じた。', choices=[1, 2, 3, 4, 5, 6, 7], widget=widgets.RadioSelectHorizontal)

for i in range(1, C.SLIDER_TASK_COUNT + 1):
    setattr(Player, f'slider_{i}', models.IntegerField())

def creating_session(subsession):
    # For GBAT matching, group assignment is made at the first wait page, not
    # at session creation. Do not group_like_round(1) here: oTree copies the
    # Round-1 GBAT groups to later rounds automatically.
    pass


def assign_catastrophe_to_fixed_group(group: Group):
    players = group.get_players()
    if len(players) != C.PLAYERS_PER_GROUP:
        group.group_timed_out = True
        for p in players:
            p.participant.vars['group_timed_out'] = True
        return

    # Set num_affected_players=0,1,2,3,4 on the session config.
    # No default: an omitted setting must not silently misassign participants.
    num_affected = group.session.config.get('num_affected_players')
    if num_affected not in (0, 1, 2, 3, 4):
        raise ValueError('Set num_affected_players to one of 0,1,2,3,4 in settings.py')

    affected_ids = set(random.sample([p.id_in_subsession for p in players], num_affected))
    for p in players:
        is_affected = p.id_in_subsession in affected_ids
        p.participant.vars['catastrophe_condition'] = num_affected
        p.participant.vars['is_affected_by_catastrophe'] = is_affected
        for p_round in p.in_all_rounds():
            p_round.loss_condition = num_affected
            p_round.is_affected_by_catastrophe = is_affected


def calculate_payoffs(group: Group):
    players = group.get_players()
    if len(players) < C.PLAYERS_PER_GROUP:
        group.group_timed_out = True
        for p in players:
            p.participant.vars['group_timed_out'] = True
        return

    group.total_contribution = sum(p.contribution for p in players)
    group.individual_share = (group.total_contribution * C.MULTIPLIER) / C.PLAYERS_PER_GROUP

    for p in players:
        endowment = p.correct_answers * C.SLIDER_REWARD
        p.payoff = endowment - p.contribution + group.individual_share

        if p.round_number == 1:
            previous_cumulative = 0
        else:
            previous = p.in_round(p.round_number - 1)
            previous_cumulative = previous.post_catastrophe_payoff if previous.round_number == C.CATASTROPHE_ROUND else previous.cumulative_payoff

        p.cumulative_payoff = previous_cumulative + p.payoff

        if p.round_number == C.CATASTROPHE_ROUND:
            p.pre_catastrophe_payoff = p.cumulative_payoff
            if p.is_affected_by_catastrophe:
                p.post_catastrophe_payoff = p.cumulative_payoff * C.CATASTROPHE_FACTOR
                p.cumulative_payoff = p.post_catastrophe_payoff
            else:
                p.post_catastrophe_payoff = p.cumulative_payoff

        if p.round_number > C.CATASTROPHE_ROUND:
            p.cumulative_payoff = p.in_round(p.round_number - 1).cumulative_payoff + p.payoff


class InitialMatching(WaitPage):
    # Must be the first page in page_sequence to use group_by_arrival_time.
    group_by_arrival_time = True
    title_text = 'メンバーの確定'
    body_text = '4人のメンバーがそろうまでお待ちください。このグループは全10ラウンドを通して固定されます。'

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def after_all_players_arrive(group: Group):
        assign_catastrophe_to_fixed_group(group)


class SliderTask(Page):
    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, C.SLIDER_TASK_COUNT + 1)]

    @staticmethod
    def js_vars(player):
        return dict(
            timeout_seconds=C.TIME_LIMIT
        )

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.correct_answers = sum(
            getattr(player, f'slider_{i}') == 50 for i in range(1, C.SLIDER_TASK_COUNT + 1)
        )
        player.participant.vars['initial_endowment'] = player.correct_answers * C.SLIDER_REWARD


class SliderResults(Page):
    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.participant.vars.get('initial_endowment', 0)
        }


class PublicGoodsGame(Page):
    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    form_model = 'player'
    form_fields = ['contribution']

    @staticmethod
    def vars_for_template(player):
        prev = player.in_round(player.round_number - 1) if player.round_number > 1 else None
        cumulative = prev.cumulative_payoff if prev else 0
        return {
            'round_number': player.round_number,
            'endowment': player.participant.vars.get('initial_endowment', 0),
            'cumulative_payoff': cumulative,
            'is_post_catastrophe': player.round_number > C.CATASTROPHE_ROUND,
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'num_participants': C.PLAYERS_PER_GROUP,
            'show_loss_warning': player.loss_condition > 0
        }


def contribution_error_message(player, value):
    earned = player.correct_answers * C.SLIDER_REWARD
    if not (0 <= value <= earned):
        return f'貢献額は0～{earned}ポイントの範囲で指定してください。'


class CustomWaitPage(WaitPage):
    # Normal round-level synchronization for the fixed group; no rematching.
    group_by_arrival_time = False
    title_text = '他のメンバーを待っています'
    body_text = '同じグループのメンバーが意思決定を終えるまでお待ちください。'

    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def after_all_players_arrive(group: Group):
        calculate_payoffs(group)


class GameResults(Page):
    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'round_number': player.round_number,
            'payoff': player.payoff,
            'remain': player.participant.vars.get('initial_endowment', 0) - player.contribution,
            'cumulative_payoff': (player.pre_catastrophe_payoff if player.round_number == C.CATASTROPHE_ROUND else player.cumulative_payoff),
            'group': player.group,
            'num_affected_players': sum(p.is_affected_by_catastrophe for p in player.group.get_players()),
            'contribution': player.contribution,
            'is_affected': player.is_affected_by_catastrophe,
            'is_post_catastrophe': player.round_number > C.CATASTROPHE_ROUND,
        }


class GroupCancelled(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 1 and player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'message': 'このグループは時間内に全員が揃わなかったため、実験を終了します。',
            'grace_message': 'ご参加いただきありがとうございました。'
        }

class CatastropheStage(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == C.CATASTROPHE_ROUND and player.loss_condition > 0 and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'pre_catastrophe_payoff': player.pre_catastrophe_payoff,
            'post_catastrophe_payoff': player.post_catastrophe_payoff,
            'is_affected': player.is_affected_by_catastrophe,
            'num_affected_players': sum(p.is_affected_by_catastrophe for p in player.group.get_players())
        }


class End(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return dict(final_cumulative_points=player.cumulative_payoff)



class QuestionnaireOwnership(Page):
    form_model = 'player'
    form_fields = ['ownership_1', 'ownership_2', 'ownership_3', 'ownership_4', 'ownership_5']
    template_name = C.NAME_IN_URL + '/Questionnaire.html'

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return dict(
            section_title='1. 心理的所有感',
            section_instruction='ゲーム中、各ラウンドであなたが使えたポイントについて、どの程度以下のように感じましたか。',
            section_number=1,
            section_total=7,
        )


class QuestionnaireGratitude(Page):
    form_model = 'player'
    form_fields = ['gratitude_1', 'gratitude_2', 'gratitude_3']
    template_name = C.NAME_IN_URL + '/Questionnaire.html'

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return dict(
            section_title='2. 感謝',
            section_instruction='ゲーム中、どの程度以下のように感じましたか。',
            section_number=2,
            section_total=7,
        )


class QuestionnaireIndebtedness(Page):
    form_model = 'player'
    form_fields = ['indebtedness_1', 'indebtedness_2', 'indebtedness_3']
    template_name = C.NAME_IN_URL + '/Questionnaire.html'

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return dict(
            section_title='3. 負債感・返報義務',
            section_instruction='ゲーム中、どの程度以下のように感じましたか。',
            section_number=3,
            section_total=7,
        )


class QuestionnaireExpectations(Page):
    form_model = 'player'
    form_fields = ['expectations_1', 'expectations_2', 'expectations_3']
    template_name = C.NAME_IN_URL + '/Questionnaire.html'

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return dict(
            section_title='4. 他者の協力期待',
            section_instruction='ゲーム中、どの程度以下のように考えていましたか。',
            section_number=4,
            section_total=7,
        )


class QuestionnaireCooperationCosts(Page):
    form_model = 'player'
    form_fields = ['cooperation_costs_1', 'cooperation_costs_2', 'cooperation_costs_3']
    template_name = C.NAME_IN_URL + '/Questionnaire.html'

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return dict(
            section_title='5. 他者の協力コストの知覚',
            section_instruction='ゲーム中、どの程度以下のように考えていましたか。',
            section_number=5,
            section_total=7,
        )


class QuestionnairePayoffUnderstanding(Page):
    form_model = 'player'
    form_fields = ['payoff_understanding_1', 'payoff_understanding_2', 'payoff_understanding_3']
    template_name = C.NAME_IN_URL + '/Questionnaire.html'

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return dict(
            section_title='6. 利得構造の理解・予測可能性',
            section_instruction='ゲームについて、どの程度以下のように感じましたか。',
            section_number=6,
            section_total=7,
        )


class QuestionnaireManipulationCheck(Page):
    form_model = 'player'
    form_fields = ['manipulation_check_1', 'manipulation_check_2']
    template_name = C.NAME_IN_URL + '/Questionnaire.html'

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return dict(
            section_title='7. 操作チェック',
            section_instruction='ゲームについて、どの程度以下のように感じましたか。',
            section_number=7,
            section_total=7,
        )

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.participant.vars['final_cumulative_for_bonus'] = float(player.cumulative_payoff)


class WaitTimeoutFallback(Page):
    @staticmethod
    def is_displayed(player):
        return player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'message': 'グループの人数が揃わなかったため、ゲームを終了します。'
        }


page_sequence = [
    InitialMatching, GroupCancelled,
    SliderTask, SliderResults, PublicGoodsGame,
    CustomWaitPage, GameResults, CatastropheStage,
    QuestionnaireOwnership, QuestionnaireGratitude, QuestionnaireIndebtedness,
    QuestionnaireExpectations, QuestionnaireCooperationCosts,
    QuestionnairePayoffUnderstanding, QuestionnaireManipulationCheck,
    End,
]
