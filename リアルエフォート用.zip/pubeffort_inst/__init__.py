from otree.api import *
import re
import random
import csv
from pathlib import Path

doc = """
pubeffort_inst: スライダータスクのみのアプリ
"""

class C(BaseConstants):
    NAME_IN_URL = 'pubeffort_inst'
    PLAYERS_PER_GROUP = 4  # ここでグループサイズを固定
    NUM_ROUNDS = 1
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10  # スライダータスク正答数に対する倍率
    FIXED_SLIDER_TASK_COUNT = 15
    FIXED_ENDOWMENT = 150
    TIME_LIMIT = 60
    MULTIPLIER = 1.6
    VIRTUAL_CONTRIBUTIONS = 100

def load_control_4_endowments():
    path = Path(__file__).with_name('control_4_endowments.csv')
    with path.open(encoding='utf-8', newline='') as file:
        return [
            (int(row['ID']), tuple(int(row[f'slider_point_{r}']) for r in range(1, 11)))
            for row in csv.DictReader(file)
        ]


def get_condition(player):
    condition = player.session.config.get('condition', 'effort_variable')
    if condition not in ('effort_variable', 'no_effort_variable',
                         'effort_fixed', 'no_effort_fixed'):
        raise ValueError(f'Unknown experimental condition: {condition}')
    return condition


def has_effort(player):
    return get_condition(player).startswith('effort_')


def is_variable(player):
    return get_condition(player).endswith('_variable')


def slider_count(player):
    return C.SLIDER_TASK_COUNT if is_variable(player) else C.FIXED_SLIDER_TASK_COUNT


def creating_session(subsession):
    condition = subsession.session.config.get('condition', 'effort_variable')
    control_rows = load_control_4_endowments() if condition == 'no_effort_variable' else None
    for player in subsession.get_players():
        player.experimental_condition = condition
        if condition == 'no_effort_variable':
            source_id, points = random.choice(control_rows)
            player.participant.vars['control_4_source_id'] = source_id
            player.participant.vars['control_4_endowments'] = points
            player.practice_endowment = random.choice(points)
        elif condition == 'no_effort_fixed':
            player.practice_endowment = C.FIXED_ENDOWMENT


class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    pass

class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    experimental_condition = models.StringField()
    practice_endowment = models.IntegerField(initial=0)
    practice_contribution = models.CurrencyField(initial=0)
    practice_total_contribution = models.CurrencyField(initial=0)
    practice_individual_share = models.CurrencyField(initial=0)
    practice_payoff = models.CurrencyField(initial=0)
    site_id = models.StringField(
        label="あなたのユーザIDを入力してください",
        max_length=5
    )
    site_pass = models.StringField(
        label="パスワードを入力してください"
    )
    slider_1 = models.IntegerField(blank=True)
    slider_2 = models.IntegerField(blank=True)
    slider_3 = models.IntegerField(blank=True)
    slider_4 = models.IntegerField(blank=True)
    slider_5 = models.IntegerField(blank=True)
    slider_6 = models.IntegerField(blank=True)
    slider_7 = models.IntegerField(blank=True)
    slider_8 = models.IntegerField(blank=True)
    slider_9 = models.IntegerField(blank=True)
    slider_10 = models.IntegerField(blank=True)
    slider_11 = models.IntegerField(blank=True)
    slider_12 = models.IntegerField(blank=True)
    slider_13 = models.IntegerField(blank=True)
    slider_14 = models.IntegerField(blank=True)
    slider_15 = models.IntegerField(blank=True)
    slider_16 = models.IntegerField(blank=True)
    slider_17 = models.IntegerField(blank=True)
    slider_18 = models.IntegerField(blank=True)
    slider_19 = models.IntegerField(blank=True)
    slider_20 = models.IntegerField(blank=True)
    slider_21 = models.IntegerField(blank=True)
    slider_22 = models.IntegerField(blank=True)
    slider_23 = models.IntegerField(blank=True)
    slider_24 = models.IntegerField(blank=True)
    slider_25 = models.IntegerField(blank=True)
    slider_26 = models.IntegerField(blank=True)
    slider_27 = models.IntegerField(blank=True)
    slider_28 = models.IntegerField(blank=True)
    slider_29 = models.IntegerField(blank=True)
    slider_30 = models.IntegerField(blank=True)
    slider_31 = models.IntegerField(blank=True)
    slider_32 = models.IntegerField(blank=True)
    slider_33 = models.IntegerField(blank=True)
    slider_34 = models.IntegerField(blank=True)
    slider_35 = models.IntegerField(blank=True)
    slider_36 = models.IntegerField(blank=True)
    slider_37 = models.IntegerField(blank=True)
    slider_38 = models.IntegerField(blank=True)
    slider_39 = models.IntegerField(blank=True)
    slider_40 = models.IntegerField(blank=True)
    slider_41 = models.IntegerField(blank=True)
    slider_42 = models.IntegerField(blank=True)
    slider_43 = models.IntegerField(blank=True)
    slider_44 = models.IntegerField(blank=True)
    slider_45 = models.IntegerField(blank=True)
    slider_46 = models.IntegerField(blank=True)
    slider_47 = models.IntegerField(blank=True)
    slider_48 = models.IntegerField(blank=True)
    slider_49 = models.IntegerField(blank=True)
    slider_50 = models.IntegerField(blank=True)

# ✅ site_id: 半角英数字・記号はOK、日本語文字は禁止
def site_id_error_message(player, value):
    if re.search(r'[\u3040-\u30FF\u4E00-\u9FFF]', value):
        return 'IDは半角英数字で入力してください'
    if len(value) > 5:
        return 'IDは5文字以内で入力してください'


# ✅ site_pass: 同様に日本語のみ禁止
def site_pass_error_message(player, value):
    if re.search(r'[\u3040-\u30FF\u4E00-\u9FFF]', value):
        return 'パスワードを正しく入力してください'

class InformedConsent(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

class Information(Page):
    form_model = 'player'
    form_fields = ['site_id', 'site_pass']

class Instruction1(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'num_participants': C.PLAYERS_PER_GROUP,
            'has_effort': has_effort(player),
            'is_variable': is_variable(player),
            'slider_count': slider_count(player),
            'fixed_endowment': C.FIXED_ENDOWMENT,
            'example_endowment': 20 if is_variable(player) else 150,
            'example_payoff_15': 17 if is_variable(player) else 147,
            'example_payoff_5': 27 if is_variable(player) else 157,
        }

class SliderTask(Page):
    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'

    @staticmethod
    def is_displayed(player):
        return has_effort(player)

    @staticmethod
    def get_form_fields(player):
        return [f'slider_{i}' for i in range(1, slider_count(player) + 1)]

    @staticmethod
    def vars_for_template(player):
        return {'slider_count': slider_count(player),
                'slider_indices': range(1, slider_count(player) + 1)}
    
    @staticmethod
    def js_vars(player):
        return dict(
            timeout_seconds=C.TIME_LIMIT, slider_count=slider_count(player)
        )

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        player.correct_answers = sum(
            getattr(player, f'slider_{i}') == 50 for i in range(1, slider_count(player) + 1)
        )
        player.practice_endowment = (player.correct_answers * C.SLIDER_REWARD
                                     if is_variable(player) else C.FIXED_ENDOWMENT)

class SliderResults(Page):
    @staticmethod
    def is_displayed(player):
        return has_effort(player)

    @staticmethod
    def vars_for_template(player: Player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.practice_endowment,
            'is_variable': is_variable(player),
        }
    
def practice_contribution_error_message(player, value):
    if value < 0 or value > player.practice_endowment:
        return f'貢献額は0から{player.practice_endowment}ポイントの範囲で入力してください。'


class PracticePublicGoodsGame(Page):
    form_model = 'player'
    form_fields = ['practice_contribution']

    @staticmethod
    def vars_for_template(player: Player):
        return {
            'practice_endowment': player.practice_endowment,
            'virtual_contributions': C.VIRTUAL_CONTRIBUTIONS,
            'num_participants': C.PLAYERS_PER_GROUP,
            'has_effort': has_effort(player),
            'is_variable': is_variable(player),
            'example_endowment': 20 if is_variable(player) else 150,
            'example_payoff_15': 17 if is_variable(player) else 147,
            'example_payoff_5': 27 if is_variable(player) else 157,
        }

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        # 仮想プレイヤーの設定値を使う
        others_contribution = C.VIRTUAL_CONTRIBUTIONS * (C.PLAYERS_PER_GROUP - 1)

        player.practice_total_contribution = player.practice_contribution + others_contribution
        player.practice_individual_share = (player.practice_total_contribution * C.MULTIPLIER) / C.PLAYERS_PER_GROUP
        player.practice_payoff = player.practice_endowment - player.practice_contribution + player.practice_individual_share

class PracticeResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'practice_contribution': player.practice_contribution,
            'practice_remain': player.practice_endowment - player.practice_contribution,
            'practice_total_contribution': player.practice_total_contribution,
            'practice_individual_share': player.practice_individual_share,
            'practice_payoff': player.practice_payoff,
        }

class Start(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

page_sequence = [InformedConsent, Information, Instruction1, SliderTask, SliderResults, PracticePublicGoodsGame, PracticeResults, Start]
