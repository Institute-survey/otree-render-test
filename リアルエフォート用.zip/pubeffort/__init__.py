from otree.api import *
import time


doc = """
pubeffort: スライダータスクと公共財ゲーム
"""

class C(BaseConstants):
    NAME_IN_URL = 'pubeffort'
    PLAYERS_PER_GROUP = 4
    NUM_ROUNDS = 10
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10
    FIXED_SLIDER_TASK_COUNT = 15
    FIXED_ENDOWMENT = 150
    MULTIPLIER = 1.6
    TIME_LIMIT = 30
    WAIT_TIMEOUT_SECONDS = 300  


def get_condition(player):
    condition = player.session.config.get('condition', 'effort_variable')
    if condition not in ('effort_variable', 'no_effort_variable',
                         'effort_fixed', 'no_effort_fixed'):
        raise ValueError(f'Unknown experimental condition: {condition}')
    return condition


def has_effort(player):
    return get_condition(player).startswith('effort_')


def is_variable(player):
    return get_condition(player).endswith('_variable')


def slider_count(player):
    return C.SLIDER_TASK_COUNT if is_variable(player) else C.FIXED_SLIDER_TASK_COUNT


class Subsession(BaseSubsession):
    pass


def group_by_arrival_time_method(subsession, waiting_players):
    now = time.time()
    required = C.PLAYERS_PER_GROUP
    round_key = 'arrival_time_round_1'

    for p in waiting_players:
        if round_key not in p.participant.vars:
            p.participant.vars[round_key] = now

    timeout_players = []
    not_timeout_players = []
    for p in waiting_players:
        arrival_time = p.participant.vars[round_key]
        elapsed = now - arrival_time
        if elapsed > C.WAIT_TIMEOUT_SECONDS:
            timeout_players.append(p)
        else:
            not_timeout_players.append(p)

    if len(not_timeout_players) >= required:
        return not_timeout_players[:required]
    if len(timeout_players) >= required:
        return timeout_players[:required]
    if timeout_players:
        p = timeout_players[0]
        p.participant.vars['group_timed_out'] = True
        return [p]
    return None


class Group(BaseGroup):
    total_contribution = models.CurrencyField(initial=0)
    individual_share = models.CurrencyField(initial=0)
    group_timed_out = models.BooleanField(initial=False)


class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    contribution = models.CurrencyField(initial=0)
    cumulative_payoff = models.CurrencyField(initial=0)
    endowment = models.CurrencyField(initial=0)
    experimental_condition = models.StringField()
    control_4_source_id = models.IntegerField(initial=0)
    slider_1 = models.IntegerField(blank=True)
    slider_2 = models.IntegerField(blank=True)
    slider_3 = models.IntegerField(blank=True)
    slider_4 = models.IntegerField(blank=True)
    slider_5 = models.IntegerField(blank=True)
    slider_6 = models.IntegerField(blank=True)
    slider_7 = models.IntegerField(blank=True)
    slider_8 = models.IntegerField(blank=True)
    slider_9 = models.IntegerField(blank=True)
    slider_10 = models.IntegerField(blank=True)
    slider_11 = models.IntegerField(blank=True)
    slider_12 = models.IntegerField(blank=True)
    slider_13 = models.IntegerField(blank=True)
    slider_14 = models.IntegerField(blank=True)
    slider_15 = models.IntegerField(blank=True)
    slider_16 = models.IntegerField(blank=True)
    slider_17 = models.IntegerField(blank=True)
    slider_18 = models.IntegerField(blank=True)
    slider_19 = models.IntegerField(blank=True)
    slider_20 = models.IntegerField(blank=True)
    slider_21 = models.IntegerField(blank=True)
    slider_22 = models.IntegerField(blank=True)
    slider_23 = models.IntegerField(blank=True)
    slider_24 = models.IntegerField(blank=True)
    slider_25 = models.IntegerField(blank=True)
    slider_26 = models.IntegerField(blank=True)
    slider_27 = models.IntegerField(blank=True)
    slider_28 = models.IntegerField(blank=True)
    slider_29 = models.IntegerField(blank=True)
    slider_30 = models.IntegerField(blank=True)
    slider_31 = models.IntegerField(blank=True)
    slider_32 = models.IntegerField(blank=True)
    slider_33 = models.IntegerField(blank=True)
    slider_34 = models.IntegerField(blank=True)
    slider_35 = models.IntegerField(blank=True)
    slider_36 = models.IntegerField(blank=True)
    slider_37 = models.IntegerField(blank=True)
    slider_38 = models.IntegerField(blank=True)
    slider_39 = models.IntegerField(blank=True)
    slider_40 = models.IntegerField(blank=True)
    slider_41 = models.IntegerField(blank=True)
    slider_42 = models.IntegerField(blank=True)
    slider_43 = models.IntegerField(blank=True)
    slider_44 = models.IntegerField(blank=True)
    slider_45 = models.IntegerField(blank=True)
    slider_46 = models.IntegerField(blank=True)
    slider_47 = models.IntegerField(blank=True)
    slider_48 = models.IntegerField(blank=True)
    slider_49 = models.IntegerField(blank=True)
    slider_50 = models.IntegerField(blank=True)


def creating_session(subsession):
    condition = subsession.session.config.get('condition', 'effort_variable')
    for player in subsession.get_players():
        player.experimental_condition = condition
        if condition == 'no_effort_variable':
            # One randomized control_4 history is shared across this player's 10 rounds.
            player.endowment = player.participant.vars['control_4_endowments'][subsession.round_number - 1]
            player.control_4_source_id = player.participant.vars['control_4_source_id']
        elif condition == 'no_effort_fixed':
            player.endowment = C.FIXED_ENDOWMENT

def calculate_payoffs(group: Group):
    players = group.get_players()
    if len(players) < C.PLAYERS_PER_GROUP:
        group.group_timed_out = True
        for p in players:
            p.participant.vars['group_timed_out'] = True
        return

    group.total_contribution = sum(p.contribution for p in players)
    group.individual_share = (group.total_contribution * C.MULTIPLIER) / C.PLAYERS_PER_GROUP

    for p in players:
        endowment = p.endowment
        p.payoff = endowment - p.contribution + group.individual_share

        if p.round_number == 1:
            p.cumulative_payoff = p.payoff
        else:
            previous = p.in_round(p.round_number - 1)
            p.cumulative_payoff = previous.cumulative_payoff + p.payoff

class InitialGroupWaitPage(WaitPage):
    group_by_arrival_time = True
    body_text = "他のプレイヤーを待っています。"

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def after_all_players_arrive(group: Group):
        if len(group.get_players()) < C.PLAYERS_PER_GROUP:
            group.group_timed_out = True
            for p in group.get_players():
                p.participant.vars['group_timed_out'] = True


class SliderTask(Page):
    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'

    @staticmethod
    def is_displayed(player):
        return has_effort(player) and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def get_form_fields(player):
        return [f'slider_{i}' for i in range(1, slider_count(player) + 1)]

    @staticmethod
    def js_vars(player):
        return dict(timeout_seconds=C.TIME_LIMIT, slider_count=slider_count(player))

    @staticmethod
    def vars_for_template(player):
        return dict(slider_count=slider_count(player),
                    slider_indices=range(1, slider_count(player) + 1))

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.correct_answers = sum(
            getattr(player, f'slider_{i}') == 50 for i in range(1, slider_count(player) + 1)
        )
        player.endowment = (player.correct_answers * C.SLIDER_REWARD
                            if is_variable(player) else C.FIXED_ENDOWMENT)
        player.participant.vars['initial_endowment'] = player.endowment


class SliderResults(Page):
    @staticmethod
    def is_displayed(player):
        return has_effort(player) and not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.endowment,
            'is_variable': is_variable(player),
        }


def contribution_error_message(player, value):
    if value < 0 or value > player.endowment:
        return f'貢献額は0から{player.endowment}ポイントの範囲で入力してください。'


class PublicGoodsGame(Page):
    form_model = 'player'
    form_fields = ['contribution']

    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        prev = player.in_round(player.round_number - 1) if player.round_number > 1 else None
        cumulative = prev.cumulative_payoff if prev else 0
        return {
            'round_number': player.round_number,
            'endowment': player.endowment,
            'cumulative_payoff': cumulative,
            'num_participants': C.PLAYERS_PER_GROUP,
            'has_effort': has_effort(player),
            'is_variable': is_variable(player),
            'example_endowment': 20 if is_variable(player) else 150,
            'example_payoff_15': 17 if is_variable(player) else 147,
            'example_payoff_5': 27 if is_variable(player) else 157,
        }


class CustomWaitPage(WaitPage):
    body_text = """
    他のプレイヤーの入力が完了するのを待っています。<br>
    こちらの画面では最大10分程度お待ちいただく可能性がございます。
    """

    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def after_all_players_arrive(group: Group):
        calculate_payoffs(group)


class GameResults(Page):
    @staticmethod
    def is_displayed(player):
        return not player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'round_number': player.round_number,
            'payoff': player.payoff,
            'remain': player.endowment - player.contribution,
            'cumulative_payoff': player.cumulative_payoff,
            'group': player.group,
            'contribution': player.contribution,
        }


class GroupCancelled(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 1 and player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'message': 'このグループは時間内に全員が揃わなかったため、実験を終了します。',
            'grace_message': 'ご参加いただきありがとうございました。'
        }


class End(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS and not player.participant.vars.get('group_timed_out', False)


class WaitTimeoutFallback(Page):
    @staticmethod
    def is_displayed(player):
        return player.participant.vars.get('group_timed_out', False)

    @staticmethod
    def vars_for_template(player):
        return {
            'message': 'グループの人数が揃わなかったため、ゲームを終了します。'
        }


page_sequence = [
    InitialGroupWaitPage, GroupCancelled,
    SliderTask, SliderResults, PublicGoodsGame,
    CustomWaitPage, GameResults, End
]
