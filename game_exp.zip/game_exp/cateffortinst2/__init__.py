from otree.api import *

doc = """
Cateffortinst: スライダータスクのみのアプリ
"""

class C(BaseConstants):
    NAME_IN_URL = 'cateffortinst2'
    PLAYERS_PER_GROUP = 2  # ここでグループサイズを固定
    NUM_ROUNDS = 1
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10  # スライダータスク正答数に対する倍率
    CATASTROPHE_FACTOR = 0.3
    TIME_LIMIT = 60

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    pass

class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)

# 50個のスライダーを動的に追加
for i in range(1, C.SLIDER_TASK_COUNT + 1):
    setattr(Player, f'slider_{i}', models.IntegerField())

class InformedConsent(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

class Instruction1(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'num_participants': C.PLAYERS_PER_GROUP
        }

class SliderTask(Page):
    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, C.SLIDER_TASK_COUNT + 1)]

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.correct_answers = sum(
            getattr(player, f'slider_{i}') == 50 for i in range(1, C.SLIDER_TASK_COUNT + 1)
        )

class SliderResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.correct_answers * C.SLIDER_REWARD
        }

class Start(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

page_sequence = [InformedConsent, Instruction1, SliderTask, SliderResults, Start]
