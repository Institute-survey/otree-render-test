from otree.api import *
import random

doc = """
Your app description
"""

class Constants(BaseConstants):
    name_in_url = 'catastrophe_draft'
    players_per_group = None
    num_rounds = 20  # 20 rounds of the game
    endowment = cu(100)
    multiplier = 2

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    total_contribution = models.CurrencyField(default=0)
    total_contribution_other = models.CurrencyField(default=0)
    individual_share = models.CurrencyField()
    individual_share_other = models.CurrencyField()
    cp1 = models.CurrencyField()
    cp2 = models.CurrencyField()
    cp_other1 = models.CurrencyField()
    cp_other2 = models.CurrencyField()
    cp_other3 = models.CurrencyField()
    error_occurred = models.BooleanField(initial=False)
    


    def set_payoffs(self):
        # Player's contribution
        player_contribution = self.get_players()[0].contribution
        # Calculate total contribution
        self.total_contribution = player_contribution + self.cp1 + self.cp2
        # Calculate share distributed to each player
        self.individual_share = self.total_contribution * Constants.multiplier / 3
        
        # Calculate total contribution
        self.total_contribution_other = self.cp3 + self.cp1 + self.cp2
        # Calculate share distributed to each player
        self.individual_share_other = self.total_contribution_other * Constants.multiplier / 3

        for p in self.get_players():
            if self.round_number == 10:
                self.error_occurred = True
                p.payoff = cu(0)
                p.participant.payoff = cu(0)
                self.total_contribution_other = cu(0)
                self.individual_share_other = cu(0)
            else:
                p.payoff = Constants.endowment - p.contribution + self.individual_share


    def random_contributions(self):
        self.cp1 = random.randint(0, Constants.endowment/10) * 10
        self.cp2 = random.randint(0, Constants.endowment/10) * 10

class Player(BasePlayer):
    contribution = models.CurrencyField(
        choices=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100], label="あなたは公共財にいくら投入しますか?"
    )

# PAGES
class Contribution(Page):
    form_model = 'player'
    form_fields = ['contribution']

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        group = player.group
        group.random_contributions()

class ResultsWaitPage(WaitPage):
    wait_for_all_groups = True

    def after_all_players_arrive(self):
        for group in self.subsession.get_groups():
            group.set_payoffs()

class Results(Page):
    @staticmethod
    def vars_for_template(player: Player):
        group = player.group
        return {
            'total_contribution': group.total_contribution,
            'individual_share': group.individual_share,
            'cp1': group.cp1,
            'cp2': group.cp2,
            'error_occurred': group.error_occurred,
            'player_contribution': player.contribution,
            'player_payoff': player.payoff,
        }

page_sequence = [Contribution, ResultsWaitPage, Results]
