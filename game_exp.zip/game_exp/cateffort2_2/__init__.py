from otree.api import *
import random

doc = """
Cateffort2_2: スライダータスクと公共財ゲームを含むメインアプリ
"""

class C(BaseConstants):
    NAME_IN_URL = 'cateffort2_2'
    PLAYERS_PER_GROUP = 2
    NUM_ROUNDS = 10
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10
    MULTIPLIER = 1.6
    CATASTROPHE_ROUND = 5
    CATASTROPHE_FACTOR = 0.3
    instructions_template = 'cateffortinst2/instruction1.html'
    TIME_LIMIT = 30

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    total_contribution = models.CurrencyField(initial=0)
    individual_share = models.CurrencyField(initial=0)

class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    contribution = models.CurrencyField(initial=0)
    cumulative_payoff = models.CurrencyField(initial=0)
    pre_catastrophe_payoff = models.CurrencyField(initial=0)
    post_catastrophe_payoff = models.CurrencyField(initial=0)
    is_affected_by_catastrophe = models.BooleanField(initial=False)

# 50個のスライダーを動的に追加
for i in range(1, C.SLIDER_TASK_COUNT + 1):
    setattr(Player, f'slider_{i}', models.IntegerField())

def creating_session(subsession):
    if subsession.round_number == 1:
        players = subsession.get_players()
        num_affected = subsession.session.config.get('num_affected_players', 1)

        for p in players:
            p.is_affected_by_catastrophe = False

        affected_players = random.sample(players, min(num_affected, len(players)))
        for p in affected_players:
            p.is_affected_by_catastrophe = True
    else:
        for p in subsession.get_players():
            p.is_affected_by_catastrophe = p.in_round(1).is_affected_by_catastrophe

def calculate_payoffs(group: Group):
    players = group.get_players()
    contributions = [p.contribution for p in players]
    group.total_contribution = sum(contributions)

    group.individual_share = (group.total_contribution * C.MULTIPLIER) / C.PLAYERS_PER_GROUP

    for p in players:
        endowment = p.correct_answers * C.SLIDER_REWARD
        p.payoff = endowment - p.contribution + group.individual_share

        # ✅ **前のラウンドの累積ポイントを取得**
        if p.round_number == 1:
            previous_cumulative = 0
        else:
            previous_player = p.in_round(p.round_number - 1)

            # ✅ **カタストロフ発生後のラウンドの場合**
            if previous_player.round_number == C.CATASTROPHE_ROUND:
                previous_cumulative = previous_player.post_catastrophe_payoff
            else:
                previous_cumulative = previous_player.cumulative_payoff

        # ✅ **累積ポイントを更新**
        p.cumulative_payoff = previous_cumulative + p.payoff

        # ✅ **カタストロフ発生時の処理**
        if p.round_number == C.CATASTROPHE_ROUND:
            p.pre_catastrophe_payoff = p.cumulative_payoff  
            
            if p.is_affected_by_catastrophe:
                p.post_catastrophe_payoff = p.cumulative_payoff * C.CATASTROPHE_FACTOR
                p.cumulative_payoff = p.post_catastrophe_payoff  # ✅ 影響を反映
            else:
                p.post_catastrophe_payoff = p.cumulative_payoff  

        # ✅ **7期以降のプレイヤーの累積ポイントを適切に反映**
        if p.round_number > C.CATASTROPHE_ROUND:
            previous_round = p.in_round(p.round_number - 1)
            p.cumulative_payoff = previous_round.cumulative_payoff + p.payoff


class SliderTask(Page):
    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, C.SLIDER_TASK_COUNT + 1)]

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.correct_answers = sum(
            getattr(player, f'slider_{i}') == 50 for i in range(1, C.SLIDER_TASK_COUNT + 1)
        )
        player.participant.vars['initial_endowment'] = player.correct_answers * C.SLIDER_REWARD

class SliderResults(Page):
    @staticmethod
    def vars_for_template(player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.participant.vars.get('initial_endowment', 0)
        }

class PublicGoodsGame(Page):
    form_model = 'player'
    form_fields = ['contribution']

    @staticmethod
    def vars_for_template(player):
        previous_cumulative = 0

        # ✅ **前ラウンドの累積ポイントを取得**
        if player.round_number > 1:
            previous_cumulative = player.in_round(player.round_number - 1).cumulative_payoff

        # ✅ **7期以降のプレイヤーのカタストロフ影響を適切に反映**
        if player.round_number > C.CATASTROPHE_ROUND:
            if player.is_affected_by_catastrophe:
                previous_cumulative = player.in_round(player.round_number - 1).cumulative_payoff

        return {
            'round_number': player.round_number,
            'endowment': player.participant.vars.get('initial_endowment', 0),
            'cumulative_payoff': previous_cumulative,  # ✅ 修正後は 0 にならない
            'is_post_catastrophe': player.round_number >= C.CATASTROPHE_ROUND,
            'instructions_template': C.instructions_template,
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'num_participants': C.PLAYERS_PER_GROUP
        }


class ResultsWaitPage(WaitPage):
    after_all_players_arrive = calculate_payoffs

class GameResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        group = player.group

        # ✅ **カタストロフ発生後の累積ポイントの処理**
        if player.round_number > C.CATASTROPHE_ROUND:
            previous_cumulative = player.in_round(player.round_number - 1).cumulative_payoff
            cumulative_payoff = previous_cumulative + player.payoff
        else:
            cumulative_payoff = player.cumulative_payoff

        return {
            'round_number': player.round_number,
            'payoff': player.payoff,
            'remain': player.participant.vars.get('initial_endowment', 0) - player.contribution,
            'cumulative_payoff': cumulative_payoff,  # ✅ 修正後は 0 にならない
            'group': group,
            'num_affected_players': sum(p.is_affected_by_catastrophe for p in group.get_players()),
            'contribution': player.contribution,
            'is_affected': player.is_affected_by_catastrophe,
            'is_post_catastrophe': player.round_number >= C.CATASTROPHE_ROUND,
        }

class CatastropheStage(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == C.CATASTROPHE_ROUND

    @staticmethod
    def vars_for_template(player: Player):
        return {
            'pre_catastrophe_payoff': player.pre_catastrophe_payoff,
            'post_catastrophe_payoff': player.post_catastrophe_payoff,
            'is_affected': player.is_affected_by_catastrophe,
            'num_affected_players': sum(p.is_affected_by_catastrophe for p in player.group.get_players())
        }

class End(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == C.NUM_ROUNDS

page_sequence = [
    SliderTask, SliderResults, PublicGoodsGame, ResultsWaitPage,
    GameResults, CatastropheStage, End
]
