from otree.api import *

class C(BaseConstants):
    NAME_IN_URL = 'catastrophe_draft'
    PLAYERS_PER_GROUP = 2
    NUM_ROUNDS = 10

    COOPERATE_PAYOFF = 3
    DEFECT_PAYOFF = 1
    TEMPTATION_PAYOFF = 5
    SUCKER_PAYOFF = 0

    PENALTY_FACTOR = 0.3  # Penalty applied after round 5
    DECISION_LIMIT = 0  # Time limit for decisions (0 means no limit)

    COOPERATE_PAYOFF = 3
    DEFECT_PAYOFF = 1
    TEMPTATION_PAYOFF = 5
    SUCKER_PAYOFF = 0

    PENALTY_FACTOR = 0.3  # Penalty applied after round 5

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    penalty_applied = models.BooleanField(initial=False)  # To track penalty application

class Player(BasePlayer):
    choice = models.StringField(choices=['Cooperate', 'Defect'], doc="Player's choice in the round")
    round_payoff = models.CurrencyField(initial=0, doc="Payoff for the current round")
    cumulative_payoff = models.CurrencyField(initial=0, doc="Cumulative payoff across all rounds")
    total_payoff = models.CurrencyField(initial=0, doc="Cumulative payoff")

def set_payoffs(group: Group):
    p1, p2 = group.get_players()

    # Calculate payoffs for this round

    if p1.choice == 'Cooperate' and p2.choice == 'Cooperate':
        p1.round_payoff = C.COOPERATE_PAYOFF
        p2.round_payoff = C.COOPERATE_PAYOFF
    elif p1.choice == 'Defect' and p2.choice == 'Defect':
        p1.round_payoff = C.DEFECT_PAYOFF
        p2.round_payoff = C.DEFECT_PAYOFF
    elif p1.choice == 'Cooperate' and p2.choice == 'Defect':
        p1.round_payoff = C.SUCKER_PAYOFF
        p2.round_payoff = C.TEMPTATION_PAYOFF
    else:  # p1 defects and p2 cooperates
        p1.round_payoff = C.TEMPTATION_PAYOFF
        p2.round_payoff = C.SUCKER_PAYOFF

    # Update total payoff
    for p in group.get_players():
        p.cumulative_payoff += p.round_payoff

def after_round(group: Group):
    if group.round_number == 5 and not group.penalty_applied:
        for p in group.get_players():
            p.total_payoff *= C.PENALTY_FACTOR
        group.penalty_applied = True

class Introduction(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == 1

    @staticmethod
    def vars_for_template(player: Player):
        return {}

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        pass

class Decision(Page):
    form_model = 'player'
    form_fields = ['choice']

    @staticmethod
    def vars_for_template(player: Player):
        return {
            'round_number': player.round_number
        }

    @staticmethod
    def get_timeout_seconds(player: Player):
        return C.DECISION_LIMIT if C.DECISION_LIMIT > 0 else None

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        if timeout_happened:
            import random
            player.choice = random.choice(['Cooperate', 'Defect'])

    @staticmethod
    def vars_for_template(player: Player):
        return {
            'round_number': player.round_number
        }

class ResultsWaitPage(WaitPage):
    after_all_players_arrive = set_payoffs

class Results(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'round_payoff': player.round_payoff,
            'total_payoff': player.total_payoff,
        }

class PenaltyNotice(Page):
    @staticmethod
    def is_displayed(player: Player):
        group = player.group
        return group.round_number == 5 and group.penalty_applied

class RestartNotice(Page):
    @staticmethod
    def is_displayed(player: Player):
        group = player.group
        return group.round_number == 6 and group.penalty_applied

page_sequence = [
    Introduction,
    Decision,
    ResultsWaitPage,
    Results,
    PenaltyNotice,
    RestartNotice,
]