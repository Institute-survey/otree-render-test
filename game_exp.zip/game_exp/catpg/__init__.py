from otree.api import *


doc = """
10期繰り返し公共財ゲーム
"""


class C(BaseConstants):
    NAME_IN_URL = 'catpg'
    PLAYERS_PER_GROUP = 4
    NUM_ROUNDS = 10
    ENDOWMENT = cu(20)  # 初期配分
    MULTIPLIER = 1.6  # 還元率
    CATASTROPHE_ROUND = 6  # 災害発生ラウンド
    CATASTROPHE_FACTOR = 0.3  # 災害時の累積ポイント減少率
    instructions_template = 'catpg/instruction.html'


class Subsession(BaseSubsession):
    pass
class Group(BaseGroup):
    total_contribution = models.CurrencyField()  # グループの総貢献額
    individual_share = models.CurrencyField()  # 一人当たりの還元額


class Player(BasePlayer):
    contribution = models.CurrencyField(  # 貢献額
        currency_range=(0, C.ENDOWMENT, 1),
        label="あなたはいくら貢献しますか？",
    )
    cumulative_payoff = models.CurrencyField()  # 累積ポイント
    pre_catastrophe_payoff = models.CurrencyField()  # 災害発生前の累積ポイント
    post_catastrophe_payoff = models.CurrencyField()  # 災害発生後の累積ポイント
    is_affected_by_catastrophe = models.BooleanField(initial=False)  # 災害による損失を受けるかどうか


def creating_session(subsession):
    if subsession.round_number == 1:
        import random
        players = subsession.get_players()
        num_affected = subsession.session.config['num_affected_players']

        # まず全員をFalseに設定
        for p in players:
            p.is_affected_by_catastrophe = False

        # ランダムに3人選んでTrueに設定
        affected_players = random.sample(players, num_affected)
        for p in affected_players:
            p.is_affected_by_catastrophe = True
    else:
        # 2ラウンド目以降は1ラウンド目の状態をコピー
        for p in subsession.get_players():
            p.is_affected_by_catastrophe = p.in_round(1).is_affected_by_catastrophe


def calculate_payoffs(group: Group):
    players = group.get_players()
    contributions = [p.contribution for p in players]
    group.total_contribution = sum(contributions)
    group.individual_share = group.total_contribution * C.MULTIPLIER / C.PLAYERS_PER_GROUP
    
    for p in players:
        # 通常の利得計算
        p.payoff = C.ENDOWMENT - p.contribution + group.individual_share
        
        # 累積ポイントの計算
        previous_rounds_payoff = sum([p_round.payoff or 0 for p_round in p.in_previous_rounds()])
        p.cumulative_payoff = previous_rounds_payoff + p.payoff
        
        # 6期目の処理
        if group.round_number == C.CATASTROPHE_ROUND:
            # 損失を受ける参加者の場合のみ累積ポイントを減少
            if p.is_affected_by_catastrophe:
                p.cumulative_payoff = p.cumulative_payoff * C.CATASTROPHE_FACTOR


# PAGES

class Introduction(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == 1


class CatastropheStage(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == C.CATASTROPHE_ROUND

    @staticmethod
    def vars_for_template(player: Player):
        # 災害発生前の累積ポイントを計算
        previous_rounds_payoff = sum([p.payoff or 0 for p in player.in_previous_rounds()])
        player.pre_catastrophe_payoff = previous_rounds_payoff + player.payoff
        
        # 災害発生後の累積ポイント（損失を受ける参加者のみ）
        if player.is_affected_by_catastrophe:
            player.post_catastrophe_payoff = player.pre_catastrophe_payoff * C.CATASTROPHE_FACTOR
        else:
            player.post_catastrophe_payoff = player.pre_catastrophe_payoff
        
        # グループ内の影響を受けるプレイヤーの数を確認
        affected_count = sum(1 for p in player.group.get_players() if p.is_affected_by_catastrophe)
        
        return {
            'pre_catastrophe_payoff': player.pre_catastrophe_payoff,
            'post_catastrophe_payoff': player.post_catastrophe_payoff,
            'is_affected': player.is_affected_by_catastrophe,
            'num_affected_players': affected_count,  # 実際に影響を受けたプレイヤー数
            'expected_num_affected': player.session.config['num_affected_players'],  # 期待される影響を受けるプレイヤー数
        }


class MyPage(Page):
    form_model = 'player'
    form_fields = ['contribution']

    @staticmethod
    def vars_for_template(player: Player):
        cumulative_payoff = sum([p.payoff or 0 for p in player.in_all_rounds()])
        
        # カタストロフ発生後は，影響を受ける参加者のみ累積ポイントを0.3倍
        if player.round_number >= C.CATASTROPHE_ROUND:
            if player.is_affected_by_catastrophe:
                post_catastrophe_payoff = cumulative_payoff * C.CATASTROPHE_FACTOR
            else:
                post_catastrophe_payoff = cumulative_payoff
            return {
                'round_number': player.round_number,
                'endowment': C.ENDOWMENT,
                'cumulative_payoff': post_catastrophe_payoff,
                'is_post_catastrophe': True,
                'is_affected': player.is_affected_by_catastrophe
            }
        else:
            return {
                'round_number': player.round_number,
                'endowment': C.ENDOWMENT,
                'cumulative_payoff': cumulative_payoff,
                'is_post_catastrophe': False,
                'is_affected': player.is_affected_by_catastrophe  # 災害発生前でも正しい状態を表示
            }


class ResultsWaitPage(WaitPage):
    @staticmethod
    def after_all_players_arrive(group: Group):
        calculate_payoffs(group)


class Results(Page):
    @staticmethod
    def vars_for_template(player: Player):
        group = player.group
        
        # グループ内の影響を受けるプレイヤーの数を確認
        affected_count = sum(1 for p in player.group.get_players() if p.is_affected_by_catastrophe)
        
        return {
            'total_contribution': group.total_contribution,
            'individual_share': group.individual_share,
            'payoff': player.payoff,
            'round_number': player.round_number,
            'cumulative_payoff': player.cumulative_payoff,
            'is_catastrophe_round': player.round_number == C.CATASTROPHE_ROUND,
            'is_affected': player.is_affected_by_catastrophe,
            'num_affected_players': affected_count,
            'expected_num_affected': player.session.config['num_affected_players'],
        }


page_sequence = [Introduction, CatastropheStage, 
                 MyPage, ResultsWaitPage, Results]
