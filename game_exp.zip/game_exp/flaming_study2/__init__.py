from otree.api import *
import random

class C(BaseConstants):
    NAME_IN_URL = 'flaming_study2'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    pass

class Player(BasePlayer):
    # Questions for each section
    q1 = models.StringField(label='Question 1', choices=['1Option A', 'Option B', 'Option C'])
    q2 = models.StringField(label='Question 2', choices=['2Option A', 'Option B', 'Option C'])
    q3 = models.StringField(label='Question 3', choices=['3Option A', 'Option B', 'Option C'])
    q4 = models.StringField(label='Question 4', choices=['4Option A', 'Option B', 'Option C'])
    q5 = models.StringField(label='Question 5', choices=['5Option A', 'Option B', 'Option C'])
    q6 = models.StringField(label='Question 6', choices=['6Option X', 'Option Y', 'Option Z'])
    q7 = models.StringField(label='Question 7', choices=['7Option X', 'Option Y', 'Option Z'])
    q8 = models.StringField(label='Question 8', choices=['8Option X', 'Option Y', 'Option Z'])
    q9 = models.StringField(label='Question 9', choices=['9Option X', 'Option Y', 'Option Z'])
    q10 = models.StringField(label='Question 10', choices=['10Option X', 'Option Y', 'Option Z'])
    q11 = models.StringField(label='Question 11', choices=['11Option M', 'Option N', 'Option O'])
    q12 = models.StringField(label='Question 12', choices=['12Option M', 'Option N', 'Option O'])
    q13 = models.StringField(label='Question 13', choices=['13Option M', 'Option N', 'Option O'])
    q14 = models.StringField(label='Question 14', choices=['14Option M', 'Option N', 'Option O'])
    q15 = models.StringField(label='Question 15', choices=['15Option M', 'Option N', 'Option O'])
    q16 = models.StringField(label='Question 16', choices=['16Option P', 'Option Q', 'Option R'])
    q17 = models.StringField(label='Question 17', choices=['17Option P', 'Option Q', 'Option R'])
    q18 = models.StringField(label='Question 18', choices=['18Option P', 'Option Q', 'Option R'])
    q19 = models.StringField(label='Question 19', choices=['19Option P', 'Option Q', 'Option R'])
    q20 = models.StringField(label='Question 20', choices=['20Option P', 'Option Q', 'Option R'])

# Descriptions
page1_description = "以下の項目はあなたにどの程度あてはまりますか。 次のうち、最も近いと思うものをひとつだけ選んでください。"

page2_description_1 = "以下の質問に回答してください。"
page2_description_2 = "以下の質問をよく読んで各問に答えてください。"

# PAGES
class SurveyPage1(Page):
    form_model = 'player'

    @staticmethod
    def is_displayed(player):
        # 初回のみシャッフルを実行
        if 'section1' not in player.participant.vars:
            section1 = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7', 'q8', 'q9', 'q10']
            random.shuffle(section1)
            player.participant.vars['section1'] = section1
        return True

    @staticmethod
    def vars_for_template(player):
        return {
            'description': page1_description,
            'section1': player.participant.vars['section1'],
        }

    @staticmethod
    def get_form_fields(player):
        return player.participant.vars['section1']


class SurveyPage2(Page):
    form_model = 'player'

    @staticmethod
    def is_displayed(player):
        # 初回のみシャッフルを実行
        if 'section3' not in player.participant.vars:
            section3 = ['q11', 'q12', 'q13', 'q14', 'q15']
            section4 = ['q16', 'q17', 'q18', 'q19', 'q20']
            random.shuffle(section3)
            random.shuffle(section4)
            player.participant.vars['section3'] = section3
            player.participant.vars['section4'] = section4

        return True

    @staticmethod
    def vars_for_template(player):
        return {
            'description_1': page2_description_1,
            'description_2': page2_description_2,
            'section3': player.participant.vars['section3'],
            'section4': player.participant.vars['section4'],
        }

    @staticmethod
    def get_form_fields(player):
        return player.participant.vars['section3'] + player.participant.vars['section4']

page_sequence = [SurveyPage1, SurveyPage2]
