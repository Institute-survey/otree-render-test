from os import environ


SESSION_CONFIGS = [
    dict(
        name='guess_two_thirds',
        display_name="Guess 2/3 of the Average",
        app_sequence=['guess_two_thirds', 'payment_info'],
        num_demo_participants=3,
    ),
    dict(
        name='survey', app_sequence=['survey', 'payment_info'], num_demo_participants=1
    ),
    dict(
    name='catastrophe_draft',
    display_name="catastrophe_draft",
    app_sequence=['catastrophe_draft'],
    num_demo_participants=2,
    ),
    dict(
    name='flaming_study2',
    display_name="flaming_study2",
    app_sequence=['flaming_study2'],
    num_demo_participants=1,
    ),
    dict(
        name="slider_task",
        display_name="slider_task",
        num_demo_participants=1,
        app_sequence=["slider_task"],
    ),
    dict(
        name="sliderRET",
        display_name="sliderRET",
        num_demo_participants=1,
        app_sequence=["sliderRET"],
    ),
    dict(
        name="catpg",
        display_name="catpg",
        num_demo_participants=4,
        num_affected_players=2,
        app_sequence=["catpg"],
    ),
    dict(
        name="cateffortinst",
        display_name="cateffortinst",
        num_demo_participants=2,
        num_affected_players=2,
        app_sequence=["cateffortinst", "cateffort"],
    ),
    dict(
        name="cateffort2_2",
        display_name="cateffortinst",
        num_demo_participants=2,
        num_affected_players=2,
        app_sequence=["cateffortinst", "cateffort"],
    ),
    dict(
        name="cateffort4_2",
        display_name="cateffortinst",
        num_demo_participants=4,
        num_affected_players=2,
        app_sequence=["cateffortinst", "cateffort"],
    ),

]

# if you set a property in SESSION_CONFIG_DEFAULTS, it will be inherited by all configs
# in SESSION_CONFIGS, except those that explicitly override it.
# the session config can be accessed from methods in your apps as self.session.config,
# e.g. self.session.config['participation_fee']

SESSION_CONFIG_DEFAULTS = dict(
    real_world_currency_per_point=1.00, participation_fee=0.00, doc=""
)

PARTICIPANT_FIELDS = []
SESSION_FIELDS = []

# ISO-639 code
# for example: de, fr, ja, ko, zh-hans
LANGUAGE_CODE = 'ja'

# e.g. EUR, GBP, CNY, JPY
REAL_WORLD_CURRENCY_CODE = 'JPY'
USE_POINTS = False

ROOMS = [
    dict(
        name='econ101',
        display_name='Econ 101 class',
        participant_label_file='_rooms/econ101.txt',
    ),
    dict(name='live_demo', display_name='Room for live demo (no participant labels)'),
]

ADMIN_USERNAME = 'admin'
# for security, best to set admin password in an environment variable
ADMIN_PASSWORD = environ.get('OTREE_ADMIN_PASSWORD')

DEMO_PAGE_INTRO_HTML = """
Here are some oTree games.
"""

#environ['DATABASE_URL'] = 'postgres://postgres:localpgql@localhost/local_otree_pg'

environ['DATABASE_URL'] = 'postgres://postgres:localpgql@localhost/local_otree_pg'

SECRET_KEY = '1719882799927'

INSTALLED_APPS = ['otree']

# adjustments for testing
# generating session configs for all varieties of features
import sys


if sys.argv[1] == 'test':
    MAX_ITERATIONS = 5
    FREEZE_TIME = 0.1
    TRIAL_PAUSE = 0.2
    TRIAL_TIMEOUT = 0.3

    SESSION_CONFIGS = [
        dict(
            name=f"testing_sliders",
            num_demo_participants=1,
            app_sequence=['sliders'],
            trial_delay=TRIAL_PAUSE,
            retry_delay=FREEZE_TIME,
            num_sliders=3,
            attempts_per_slider=3,
        ),
    ]
    for task in ['decoding', 'matrix', 'transcription']:
        SESSION_CONFIGS.extend(
            [
                dict(
                    name=f"testing_{task}_defaults",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                ),
                dict(
                    name=f"testing_{task}_retrying",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                    attempts_per_puzzle=5,
                ),
                dict(
                    name=f"testing_{task}_limited",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                    max_iterations=MAX_ITERATIONS,
                ),
            ]
        )
