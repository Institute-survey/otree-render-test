from otree.api import *

doc = """
Your app description
"""

class C(BaseConstants):
    NAME_IN_URL = 'cateffortinst'
    PLAYERS_PER_GROUP = 2  # None ではなく creating_session で設定
    NUM_ROUNDS = 1
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10  # スライダータスク正答数に対する倍率
    CATASTROPHE_FACTOR = 0.3

class Subsession(BaseSubsession):
    def creating_session(self):
        session = self.session
        num_participants = session.config.get('num_demo_participants')
        session.vars['players_per_group'] = players_per_group  # ここで値を保存


class Group(BaseGroup):
    pass

class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)

# 50個のスライダーを動的に追加
for i in range(1, C.SLIDER_TASK_COUNT + 1):
    setattr(Player, f'slider_{i}', models.IntegerField())

class InformedConsent(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

class Instruction1(Page):
    @staticmethod
    def vars_for_template(player: Player):
        num_participants = player.session.vars.get('players_per_group') 
        return {
            'CATASTROPHE_FACTOR': C.CATASTROPHE_FACTOR,
            'num_participants': num_participants
        }

class SliderTask(Page):
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, C.SLIDER_TASK_COUNT + 1)]

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.correct_answers = sum(
            getattr(player, f'slider_{i}') == 50 for i in range(1, C.SLIDER_TASK_COUNT + 1)
        )

class SliderResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.correct_answers * C.SLIDER_REWARD
        }

class Start(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return {}

page_sequence = [InformedConsent, Instruction1, SliderTask, SliderResults, Start]
