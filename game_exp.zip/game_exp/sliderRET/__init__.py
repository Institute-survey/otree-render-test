from otree.api import *

doc = """
Simple slider task
"""

class Constants(BaseConstants):
    name_in_url = 'sliderRET'
    players_per_group = None
    num_rounds = 1
    timelimit = 120

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    pass

class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    
    def count_correct_answers(self):
        self.correct_answers = 0
        for i in range(1, 51):  # 50個のスライダーをチェック
            v = getattr(self, f'slider_{i}')
            if v == 50:  # スライダーが50に設定されているかチェック
                self.correct_answers += 1

# 50個のスライダーを作成
for i in range(1, 51):
    setattr(Player, f'slider_{i}', models.IntegerField())

class Task(Page):
    timeout_seconds = Constants.timelimit
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, 51)]

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.count_correct_answers()

class Results(Page):
    pass

page_sequence = [Task, Results]
