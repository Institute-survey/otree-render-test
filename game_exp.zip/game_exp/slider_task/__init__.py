from otree.api import *

class C(BaseConstants):
    NAME_IN_URL = 'slider_task'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1
    NUM_SLIDERS = 10
    SLIDER_TARGET = 50

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    pass

class Player(BasePlayer):
    correct_sliders = models.IntegerField(initial=0)

class Game(Page):
    timeout_seconds = 120

    @staticmethod
    def vars_for_template(player):
        return dict(
            sliders=range(1, C.NUM_SLIDERS + 1),
            target_value=C.SLIDER_TARGET,
        )

    @staticmethod
    def before_next_page(player, timeout_happened):
        slider_values = player.participant.vars.get('slider_values', {})
        correct_count = sum(1 for value in slider_values.values() if value == C.SLIDER_TARGET)
        player.correct_sliders = correct_count

class Results(Page):
    @staticmethod
    def vars_for_template(player):
        return dict(
            correct_sliders=player.correct_sliders
        )

page_sequence = [Game, Results]
