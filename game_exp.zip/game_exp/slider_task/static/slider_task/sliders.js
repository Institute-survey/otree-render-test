document.addEventListener('DOMContentLoaded', function () {
    const sliders = document.querySelectorAll('.slider');
    const form = document.getElementById('form');
    const correctSlidersInput = document.getElementById('correct-sliders');
    const targetValue = 50;

    sliders.forEach((slider) => {
        slider.addEventListener('input', function () {
            let correctCount = 0;
            sliders.forEach((s) => {
                if (parseInt(s.value) === targetValue) {
                    correctCount++;
                }
            });
            correctSlidersInput.value = correctCount;
        });
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        alert('正解したスライダー数: ' + correctSlidersInput.value);
        form.submit();
    });
});
