from otree.api import *
import random

doc = """
Cateffort: 公共財ゲームを含むメインアプリ
"""

class C(BaseConstants):
    NAME_IN_URL = 'cateffort'
    PLAYERS_PER_GROUP = 4  # グループサイズを固定
    NUM_ROUNDS = 10
    SLIDER_TASK_COUNT = 50
    SLIDER_REWARD = 10  # スライダータスク正答数に対する倍率
    MULTIPLIER = 1.6  # 公共財ゲームの還元率
    CATASTROPHE_ROUND = 5  # 災害発生ラウンド
    CATASTROPHE_FACTOR = 0.3  # 災害時の累積ポイント減少率
    instructions_template = 'cateffort/instruction.html'
    TIME_LIMIT = 30

class Subsession(BaseSubsession):
    def creating_session(self):
        if self.round_number == 1:
            # グループごとに影響を受けるプレイヤーを決定
            for group in self.get_groups():
                players = group.get_players()
                num_affected_players = session.config.get('num_affected_players', 1)
        
                # 影響を受ける人数がグループサイズより多い場合は調整
                num_affected_players = min(num_affected_players, len(players))
        
                # 影響を受けるプレイヤーをランダムに決定
                affected_players = random.sample(players, num_affected_players)
                for p in affected_players:
                    p.is_affected_by_catastrophe = True
        else:
            # 2ラウンド目以降は1ラウンド目の影響をコピー
            for p in self.get_players():
                p.is_affected_by_catastrophe = p.in_round(1).is_affected_by_catastrophe

class Group(BaseGroup):
    total_contribution = models.CurrencyField(initial=0)
    individual_share = models.CurrencyField(initial=0)

class Player(BasePlayer):
    correct_answers = models.IntegerField(initial=0)
    contribution = models.CurrencyField(initial=0)
    cumulative_payoff = models.CurrencyField(initial=0)
    pre_catastrophe_payoff = models.CurrencyField()
    post_catastrophe_payoff = models.CurrencyField()
    is_affected_by_catastrophe = models.BooleanField(initial=False)

# 50個のスライダーを動的に追加
for i in range(1, C.SLIDER_TASK_COUNT + 1):
    setattr(Player, f'slider_{i}', models.IntegerField())

def calculate_payoffs(group: Group):
    players = group.get_players()
    contributions = [p.contribution for p in players]
    group.total_contribution = sum(contributions)

    group.individual_share = (group.total_contribution * C.MULTIPLIER) / C.PLAYERS_PER_GROUP

    for p in players:
        endowment = p.correct_answers * C.SLIDER_REWARD
        p.payoff = endowment - p.contribution + group.individual_share
        previous_rounds_payoff = sum([pr.payoff or 0 for pr in p.in_previous_rounds()])
        p.cumulative_payoff = previous_rounds_payoff + p.payoff
        
        if group.round_number == C.CATASTROPHE_ROUND:
            p.pre_catastrophe_payoff = p.cumulative_payoff
            if p.is_affected_by_catastrophe:
                p.post_catastrophe_payoff = p.cumulative_payoff * C.CATASTROPHE_FACTOR
                p.cumulative_payoff *= C.CATASTROPHE_FACTOR
            else:
                p.post_catastrophe_payoff = p.cumulative_payoff

class SliderTask(Page):
    timeout_seconds = C.TIME_LIMIT
    form_model = 'player'
    form_fields = [f'slider_{i}' for i in range(1, C.SLIDER_TASK_COUNT + 1)]

    @staticmethod
    def before_next_page(player, timeout_happened):
        player.correct_answers = sum(
            getattr(player, f'slider_{i}') == 50 for i in range(1, C.SLIDER_TASK_COUNT + 1)
        )
        player.participant.vars['initial_endowment'] = player.correct_answers * C.SLIDER_REWARD

class SliderResults(Page):
    @staticmethod
    def vars_for_template(player):
        return {
            'correct_answers': player.correct_answers,
            'next_endowment': player.participant.vars.get('initial_endowment', 0)
        }

class PublicGoodsGame(Page):
    form_model = 'player'
    form_fields = ['contribution']

    @staticmethod
    def vars_for_template(player):
        return {
            'round_number': player.round_number,
            'endowment': player.participant.vars.get('initial_endowment', 0),
            'cumulative_payoff': player.cumulative_payoff,
            'is_post_catastrophe': player.round_number >= C.CATASTROPHE_ROUND
        }

class ResultsWaitPage(WaitPage):
    after_all_players_arrive = calculate_payoffs

class GameResults(Page):
    @staticmethod
    def vars_for_template(player: Player):
        group = player.group
        return {
            'round_number': player.round_number,
            'payoff': player.payoff,
            'cumulative_payoff': player.cumulative_payoff,
            'group': group,
            'num_affected_players': sum(p.is_affected_by_catastrophe for p in group.get_players()),
            'expected_num_affected': C.PLAYERS_PER_GROUP // 2,  # 影響を受ける人数をグループサイズの半分に設定
            'is_affected': player.is_affected_by_catastrophe,
            'is_post_catastrophe': player.round_number >= C.CATASTROPHE_ROUND,
        }

class CatastropheStage(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == C.CATASTROPHE_ROUND

    @staticmethod
    def vars_for_template(player: Player):
        affected_count = sum(1 for p in player.group.get_players() if p.is_affected_by_catastrophe)
        return {
            'pre_catastrophe_payoff': player.pre_catastrophe_payoff,
            'post_catastrophe_payoff': player.post_catastrophe_payoff,
            'is_affected': player.is_affected_by_catastrophe,
            'num_affected_players': affected_count
        }

class End(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == C.NUM_ROUNDS  # 最後のラウンドのみ表示

    @staticmethod
    def vars_for_template(player: Player):
        return {}

page_sequence = [
    SliderTask, SliderResults, PublicGoodsGame, ResultsWaitPage,
    GameResults, CatastropheStage, End
]
